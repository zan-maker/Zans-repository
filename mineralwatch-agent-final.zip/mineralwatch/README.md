# MineralWatch Agent 🪨⚡

**AI-powered critical minerals supply chain risk intelligence — secured by Auth0 Token Vault across GitHub, Google Sheets, and Notion.**

> Built for the [Authorized to Act: Auth0 for AI Agents](https://authorizedtoact.devpost.com/) Hackathon

![Architecture](./docs/architecture.png)

---

## What It Does

MineralWatch is an AI agent that monitors battery supply chain risk by:

1. **Ingesting live data** from FRED (macro indicators), Alpha Vantage (commodity prices), and SEC EDGAR (company filings)
2. **Running AI analysis** — HMM price regime detection, macro correlation, and Gemini-powered regulatory NLP
3. **Publishing intelligence** to three OAuth-protected services via Auth0 Token Vault:
   - **GitHub** → reads versioned agent configuration (thresholds, watchlists, scoring weights)
   - **Google Sheets** → writes daily price/risk data rows
   - **Notion** → creates risk alert database entries, weekly digest pages, and regulatory timelines

Public data flows through API keys. Private actions flow through Token Vault. The agent code never touches a raw OAuth token.

---

## Architecture

```
[Auth0 Universal Login] → [Token Vault]
                               ↓
                    ┌──────────┼──────────┐
                    ↓          ↓          ↓
               [GitHub]   [Google     [Notion]
               (config)    Sheets]    (alerts +
                          (data)      reports)
                               ↑
              [Vercel AI SDK + Gemini Agent]
                               ↑
                    ┌──────────┼──────────┐
                    ↓          ↓          ↓
               [FRED]   [Alpha       [SEC
               (macro)   Vantage]    EDGAR]
                         (prices)   (filings)
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 14 (App Router) |
| Auth | Auth0 (`@auth0/nextjs-auth0`) |
| Token Management | Auth0 Token Vault (`@auth0/ai-vercel`) |
| AI Framework | Vercel AI SDK |
| LLM | Google Gemini 2.0 Flash |
| Token Vault Connections | GitHub, Google Sheets, Notion |
| Public Data APIs | FRED, Alpha Vantage, SEC EDGAR |
| Deployment | Vercel |

---

## Getting Started

### Prerequisites

- Node.js 18+
- An [Auth0](https://auth0.com) account (free tier works)
- API keys for: [FRED](https://fred.stlouisfed.org/docs/api/api_key.html), [Alpha Vantage](https://www.alphavantage.co/support/#api-key), [Google Gemini](https://aistudio.google.com/apikey)
- A GitHub repo for agent config (can be private)
- A Google account (for Sheets)
- A Notion workspace

### 1. Clone and Install

```bash
git clone https://github.com/yourusername/mineralwatch-agent.git
cd mineralwatch-agent
npm install
```

### 2. Auth0 Setup

#### Create Application
1. Go to **Auth0 Dashboard → Applications → Create Application**
2. Select **Regular Web Application**
3. Note your `Domain`, `Client ID`, and `Client Secret`
4. Set **Allowed Callback URLs**: `http://localhost:3000/api/auth/callback`
5. Set **Allowed Logout URLs**: `http://localhost:3000`
6. Under **Advanced Settings → Grant Types**, enable **Token Exchange**

#### Configure Token Vault Connections

**GitHub Connection:**
1. **Authentication → Social → GitHub**
2. Enable **Token Vault** in Advanced Settings
3. Scopes: `repo`
4. Create a GitHub OAuth App at https://github.com/settings/developers

**Google Connection:**
1. **Authentication → Social → Google**
2. Enable **Token Vault** in Advanced Settings
3. Scopes: `https://www.googleapis.com/auth/spreadsheets`
4. Create OAuth credentials at https://console.cloud.google.com

**Notion Connection:**
1. **Authentication → Social → Create Custom Connection** (if Notion isn't listed)
2. Or use Auth0's Notion integration if available
3. Enable **Token Vault**
4. Create a Notion integration at https://www.notion.so/my-integrations

### 3. Environment Variables

Copy the example env file and fill in your values:

```bash
cp .env.example .env.local
```

```env
# Auth0
AUTH0_SECRET=<generate with: openssl rand -hex 32>
AUTH0_BASE_URL=http://localhost:3000
AUTH0_ISSUER_BASE_URL=https://YOUR_DOMAIN.auth0.com
AUTH0_CLIENT_ID=your_client_id
AUTH0_CLIENT_SECRET=your_client_secret

# Public Data API Keys
FRED_API_KEY=your_fred_key
ALPHA_VANTAGE_API_KEY=your_alpha_vantage_key
GEMINI_API_KEY=your_gemini_key

# GitHub Config Repo
GITHUB_CONFIG_REPO=yourusername/mineralwatch-config
GITHUB_CONFIG_PATH=config.yaml

# Google Sheets
GOOGLE_SHEET_ID=your_spreadsheet_id

# Notion
NOTION_DATABASE_PARENT_PAGE_ID=your_parent_page_id
```

### 4. Set Up Config Repo

Create a GitHub repository (can be private) with a `config.yaml` file:

```bash
cp config/config.example.yaml config.yaml
# Edit to your preferences, then push to your config repo
```

See [config/config.example.yaml](./config/config.example.yaml) for the full schema.

### 5. Set Up Google Sheet

Create a Google Sheet with the following header row in Sheet1:

| Date | Mineral | Price_USD | Volatility_60d | Risk_Score | Regime | PPI_Metals | PMI | Yield_Spread |
|------|---------|-----------|----------------|------------|--------|------------|-----|--------------|

Note the Sheet ID from the URL: `https://docs.google.com/spreadsheets/d/SHEET_ID/edit`

### 6. Set Up Notion

1. Create a page in your Notion workspace to serve as the parent
2. Share that page during the OAuth consent flow
3. The agent will auto-create three databases on first run:
   - Risk Alerts
   - Weekly Digests
   - Regulatory Timeline

### 7. Run

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) and log in via Auth0.

---

## Agent Configuration

The agent reads its configuration from a YAML file in your GitHub repo via Token Vault. This means:

- **Anyone on the team** can edit thresholds by committing to the repo
- **Every change is versioned** with full Git history
- **No redeployment needed** — the agent reads fresh config on each run

See [config/config.example.yaml](./config/config.example.yaml) for all options.

---

## How Token Vault Is Used

| Tool | Connection | Scopes | Purpose |
|---|---|---|---|
| `readGitHubConfig` | GitHub | `repo` | Read YAML config from private repo |
| `appendToSheet` | Google | `spreadsheets` | Write daily price + risk rows |
| `createNotionAlert` | Notion | Page access | Create risk alert database entry |
| `createNotionDigest` | Notion | Page access | Generate weekly digest page |
| `updateRegulatoryTimeline` | Notion | Page access | Update milestone database |

**Public data tools** (`fetchFREDData`, `fetchCommodityPrices`, `fetchSECFilings`) use standard API keys — no Token Vault needed.

**Design principle:** Public data in via API keys. Private actions out via Token Vault. The security boundary is explicit.

---

## Deployment (Vercel)

```bash
npm install -g vercel
vercel
```

Set all environment variables in Vercel Dashboard → Settings → Environment Variables.

Update Auth0 callback URLs to your production domain.

---

## Project Structure

```
mineralwatch-agent/
├── src/
│   ├── app/
│   │   ├── layout.tsx              # Root layout with Auth0 provider
│   │   ├── page.tsx                # Main dashboard / chat interface
│   │   └── api/
│   │       ├── auth/[...auth0]/
│   │       │   └── route.ts        # Auth0 route handler
│   │       ├── chat/
│   │       │   └── route.ts        # Vercel AI SDK chat endpoint
│   │       └── cron/
│   │           └── route.ts        # Scheduled daily/weekly runs
│   ├── lib/
│   │   ├── auth0.ts                # Auth0 client + refresh token helper
│   │   ├── auth0-ai.ts             # Token Vault connection wrappers
│   │   ├── tools/
│   │   │   ├── github-config.ts    # Read config from GitHub (Token Vault)
│   │   │   ├── google-sheets.ts    # Write to Sheets (Token Vault)
│   │   │   ├── notion-alerts.ts    # Create Notion alerts (Token Vault)
│   │   │   ├── notion-digest.ts    # Generate Notion digests (Token Vault)
│   │   │   ├── notion-timeline.ts  # Update regulatory timeline (Token Vault)
│   │   │   ├── fred.ts             # FRED API data fetch (API key)
│   │   │   ├── alpha-vantage.ts    # Commodity price fetch (API key)
│   │   │   └── sec-edgar.ts        # SEC filing fetch (API key)
│   │   ├── analysis/
│   │   │   ├── hmm-regime.ts       # Hidden Markov Model regime detection
│   │   │   ├── macro-signal.ts     # Macro indicator correlation
│   │   │   ├── regulatory-nlp.ts   # Gemini regulatory classification
│   │   │   └── risk-scorer.ts      # Composite Bayesian risk score
│   │   └── config/
│   │       └── types.ts            # Config YAML type definitions
│   └── components/
│       ├── chat-interface.tsx       # Chat UI component
│       ├── risk-dashboard.tsx       # Risk score display
│       └── connection-status.tsx    # Token Vault connection indicators
├── config/
│   └── config.example.yaml         # Example agent configuration
├── docs/
│   └── architecture.png            # Architecture diagram
├── .env.example                    # Environment variable template
├── .gitignore
├── next.config.js
├── package.json
├── tsconfig.json
├── tailwind.config.ts
├── postcss.config.js
├── vercel.json
├── LICENSE
└── README.md
```

---

## License

MIT — see [LICENSE](./LICENSE).

---

## Acknowledgements

- [Auth0 for AI Agents](https://auth0.com/ai) — Token Vault, async authorization, identity infrastructure
- [Vercel AI SDK](https://sdk.vercel.ai/) — tool composition and streaming
- [FRED](https://fred.stlouisfed.org/) — Federal Reserve economic data
- [Alpha Vantage](https://www.alphavantage.co/) — commodity price data
- [SEC EDGAR](https://www.sec.gov/edgar) — public company filings

---

*Built with Auth0 Token Vault. Three providers, zero stored tokens.*
