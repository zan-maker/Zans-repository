import { GoogleGenerativeAI } from "@google/generative-ai";

/**
 * Regulatory NLP classification using Google Gemini.
 *
 * Classifies SEC filing text excerpts by:
 * - Regulatory relevance (FEOC, IRA, CRMA, none)
 * - Sentiment (risk, opportunity, neutral)
 * - Material flag (yes/no — should this trigger an alert?)
 */

export interface RegulatoryClassification {
  regulatory_category: "FEOC" | "IRA_45X" | "EU_CRMA" | "other" | "none";
  sentiment: "risk" | "opportunity" | "neutral";
  is_material: boolean;
  confidence: number;
  summary: string;
}

const CLASSIFICATION_PROMPT = `You are a regulatory analyst specializing in critical minerals and battery supply chain policy. 

Classify the following SEC filing excerpt along three dimensions:

1. **Regulatory Category**: Which regulation is most relevant?
   - FEOC: Foreign Entity of Concern rules, Chinese battery procurement ban
   - IRA_45X: Inflation Reduction Act Section 45X production credits
   - EU_CRMA: EU Critical Raw Materials Act due diligence
   - other: Other regulation mentioned
   - none: No regulatory content

2. **Sentiment**: What is the filing's tone regarding this regulation?
   - risk: The company views this as a threat or challenge
   - opportunity: The company views this as beneficial or advantageous
   - neutral: Factual mention without clear sentiment

3. **Material**: Is this mention significant enough to warrant an alert?
   - true: New development, material impact, or change in compliance status
   - false: Boilerplate, routine disclosure, or immaterial mention

Respond ONLY with JSON in this exact format:
{
  "regulatory_category": "FEOC|IRA_45X|EU_CRMA|other|none",
  "sentiment": "risk|opportunity|neutral",
  "is_material": true|false,
  "confidence": 0.0-1.0,
  "summary": "One sentence explanation"
}

Filing excerpt:
`;

/**
 * Classify a SEC filing excerpt for regulatory relevance.
 */
export async function classifyRegulatory(
  filingText: string
): Promise<RegulatoryClassification> {
  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
  const model = genAI.getGenerativeModel({
    model: "gemini-2.0-flash",
    generationConfig: { temperature: 0.1 },
  });

  try {
    // Truncate to avoid token limits
    const excerpt = filingText.slice(0, 3000);
    const result = await model.generateContent(
      CLASSIFICATION_PROMPT + excerpt
    );
    const responseText = result.response.text();

    // Parse JSON response (strip markdown fences if present)
    const clean = responseText.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean) as RegulatoryClassification;

    return {
      regulatory_category: parsed.regulatory_category || "none",
      sentiment: parsed.sentiment || "neutral",
      is_material: parsed.is_material || false,
      confidence: parsed.confidence || 0.5,
      summary: parsed.summary || "Classification completed",
    };
  } catch (error) {
    return {
      regulatory_category: "none",
      sentiment: "neutral",
      is_material: false,
      confidence: 0,
      summary: `Classification failed: ${error instanceof Error ? error.message : "unknown error"}`,
    };
  }
}

/**
 * Generate a natural-language alert summary using Gemini.
 */
export async function generateAlertSummary(context: {
  mineral: string;
  trigger_type: string;
  risk_score: number;
  price_data?: { price: number; change_pct: number };
  macro_data?: { indicator: string; value: number }[];
  regulatory_data?: RegulatoryClassification;
}): Promise<string> {
  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
  const model = genAI.getGenerativeModel({
    model: "gemini-2.0-flash",
    generationConfig: { temperature: 0.3 },
  });

  const prompt = `Write a concise (2-3 sentence) risk alert summary for a supply chain team.

Context:
- Mineral: ${context.mineral}
- Trigger: ${context.trigger_type}
- Risk Score: ${context.risk_score}/100
${context.price_data ? `- Price: $${context.price_data.price} (${context.price_data.change_pct > 0 ? "+" : ""}${context.price_data.change_pct}%)` : ""}
${context.macro_data ? `- Macro signals: ${context.macro_data.map((m) => `${m.indicator}: ${m.value}`).join(", ")}` : ""}
${context.regulatory_data ? `- Regulatory: ${context.regulatory_data.regulatory_category} — ${context.regulatory_data.summary}` : ""}

Write the alert as if briefing a CFO. Be specific about what changed and what it means. No fluff.`;

  try {
    const result = await model.generateContent(prompt);
    return result.response.text().trim();
  } catch {
    return `${context.mineral} risk score at ${context.risk_score}/100. Trigger: ${context.trigger_type}. Review recommended.`;
  }
}
