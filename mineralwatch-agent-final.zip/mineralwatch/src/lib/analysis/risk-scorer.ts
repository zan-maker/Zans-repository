/**
 * Composite Bayesian risk scoring.
 *
 * Combines five risk dimensions into a single 0-100 score
 * with confidence intervals using Beta distribution priors.
 *
 * P(θ|D) ∝ P(D|θ) · P(θ)
 *
 * Priors: Historical disruption base rates (~2.3 events/decade/mineral)
 * Posteriors: Updated with each new data pull
 */

import type { ScoringWeights } from "../config/types";
import type { RegimeResult } from "./hmm-regime";
import type { MacroStressResult } from "./macro-signal";
import type { RegulatoryClassification } from "./regulatory-nlp";

export interface RiskScoreResult {
  composite_score: number; // 0-100
  confidence_interval: { lower: number; upper: number };
  components: {
    price_volatility: number;
    macro_stress: number;
    regulatory_impact: number;
    concentration_risk: number;
    demand_signal: number;
  };
  top_drivers: string[];
}

// Geographic concentration HHI scores (static reference data from USGS)
const CONCENTRATION_HHI: Record<string, number> = {
  lithium_carbonate: 0.42, // China ~65% refining
  nickel_sulfate: 0.30, // Indonesia ~50%
  cobalt_hydroxide: 0.49, // DRC ~70% mining
  manganese_sulfate: 0.35, // South Africa ~30%, Gabon ~20%
};

// Demand signal scores (simplified static estimate)
const DEMAND_SIGNAL: Record<string, number> = {
  lithium_carbonate: 70, // Strong EV demand growth
  nickel_sulfate: 55,
  cobalt_hydroxide: 45, // Declining with LFP shift
  manganese_sulfate: 60,
};

/**
 * Calculate composite risk score with Bayesian confidence intervals.
 */
export function calculateRiskScore(
  mineral: string,
  regime: RegimeResult,
  macroStress: MacroStressResult,
  regulatory: RegulatoryClassification | null,
  weights: ScoringWeights
): RiskScoreResult {
  // Component 1: Price volatility (from HMM regime)
  const priceVolatility = regimeToScore(regime);

  // Component 2: Macro stress
  const macroScore = macroStress.composite_stress;

  // Component 3: Regulatory impact
  const regulatoryScore = regulatoryToScore(regulatory);

  // Component 4: Concentration risk (static HHI-based)
  const hhi = CONCENTRATION_HHI[mineral] || 0.3;
  const concentrationScore = Math.round(hhi * 100);

  // Component 5: Demand signal (static estimate)
  const demandScore = DEMAND_SIGNAL[mineral] || 50;

  // Weighted composite
  const composite =
    priceVolatility * weights.price_volatility_weight +
    macroScore * weights.macro_stress_weight +
    regulatoryScore * weights.regulatory_impact_weight +
    concentrationScore * weights.concentration_risk_weight +
    demandScore * weights.demand_signal_weight;

  const compositeScore = Math.round(Math.min(Math.max(composite, 0), 100));

  // Bayesian confidence interval using Beta distribution approximation
  // Prior: Beta(2.3, 7.7) based on ~23% historical disruption rate
  const alpha = 2.3 + compositeScore / 20;
  const beta = 7.7 + (100 - compositeScore) / 20;
  const posteriorMean = alpha / (alpha + beta);
  const posteriorVar =
    (alpha * beta) / ((alpha + beta) ** 2 * (alpha + beta + 1));
  const stdDev = Math.sqrt(posteriorVar) * 100;

  const ci = {
    lower: Math.round(Math.max(compositeScore - 1.96 * stdDev, 0)),
    upper: Math.round(Math.min(compositeScore + 1.96 * stdDev, 100)),
  };

  // Identify top drivers
  const components = {
    price_volatility: priceVolatility,
    macro_stress: macroScore,
    regulatory_impact: regulatoryScore,
    concentration_risk: concentrationScore,
    demand_signal: demandScore,
  };

  const sortedDrivers = Object.entries(components)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([key, value]) => `${key.replace(/_/g, " ")}: ${value}/100`);

  return {
    composite_score: compositeScore,
    confidence_interval: ci,
    components,
    top_drivers: sortedDrivers,
  };
}

function regimeToScore(regime: RegimeResult): number {
  const baseScores: Record<string, number> = {
    low_volatility: 20,
    trending: 50,
    crisis: 85,
  };
  const base = baseScores[regime.current_state] || 30;
  const transitionBonus = regime.transition_detected ? 15 : 0;
  return Math.min(base + transitionBonus, 100);
}

function regulatoryToScore(
  regulatory: RegulatoryClassification | null
): number {
  if (!regulatory || regulatory.regulatory_category === "none") return 20;

  let base = 40;

  // Category weight
  if (
    regulatory.regulatory_category === "FEOC" ||
    regulatory.regulatory_category === "IRA_45X"
  ) {
    base = 60;
  }

  // Sentiment modifier
  if (regulatory.sentiment === "risk") base += 20;
  if (regulatory.sentiment === "opportunity") base -= 15;

  // Material flag
  if (regulatory.is_material) base += 15;

  return Math.min(Math.max(Math.round(base * regulatory.confidence), 0), 100);
}
