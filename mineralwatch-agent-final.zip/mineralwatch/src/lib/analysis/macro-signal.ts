/**
 * Macro signal analysis for commodity price correlation.
 *
 * Evaluates whether macro indicators (PPI, PMI, yield spread)
 * are signaling stress that historically precedes commodity disruptions.
 */

export interface MacroSignal {
  indicator: string;
  latest_value: number;
  pct_change: number;
  threshold_breached: boolean;
  signal_strength: number; // 0-1 normalized
  direction: "bullish" | "bearish" | "neutral";
}

export interface MacroStressResult {
  composite_stress: number; // 0-100
  signals: MacroSignal[];
  any_threshold_breached: boolean;
}

/**
 * Evaluate macro stress based on indicator values and thresholds.
 */
export function evaluateMacroStress(
  indicators: Array<{
    name: string;
    latest_value: number;
    pct_change: number;
    threshold_pct_change?: number;
    threshold_value?: number;
  }>
): MacroStressResult {
  const signals: MacroSignal[] = indicators.map((ind) => {
    let thresholdBreached = false;
    let signalStrength = 0;
    let direction: "bullish" | "bearish" | "neutral" = "neutral";

    // Check percentage change threshold
    if (ind.threshold_pct_change !== undefined) {
      if (ind.threshold_pct_change < 0) {
        // Negative threshold = alert on drops
        thresholdBreached = ind.pct_change <= ind.threshold_pct_change;
        signalStrength = Math.min(
          Math.abs(ind.pct_change / ind.threshold_pct_change),
          2
        ) / 2;
        direction = ind.pct_change < 0 ? "bearish" : "bullish";
      } else {
        thresholdBreached = ind.pct_change >= ind.threshold_pct_change;
        signalStrength = Math.min(
          ind.pct_change / ind.threshold_pct_change,
          2
        ) / 2;
        direction = ind.pct_change > 0 ? "bullish" : "bearish";
      }
    }

    // Check absolute value threshold
    if (ind.threshold_value !== undefined) {
      if (ind.threshold_value < 0) {
        thresholdBreached =
          thresholdBreached || ind.latest_value <= ind.threshold_value;
        direction = ind.latest_value < 0 ? "bearish" : "bullish";
      } else {
        thresholdBreached =
          thresholdBreached || ind.latest_value >= ind.threshold_value;
      }
      signalStrength = Math.max(
        signalStrength,
        Math.min(Math.abs(ind.latest_value / ind.threshold_value), 2) / 2
      );
    }

    return {
      indicator: ind.name,
      latest_value: ind.latest_value,
      pct_change: ind.pct_change,
      threshold_breached: thresholdBreached,
      signal_strength: Math.round(signalStrength * 100) / 100,
      direction,
    };
  });

  // Composite stress: weighted average of signal strengths
  const avgStrength =
    signals.reduce((sum, s) => sum + s.signal_strength, 0) / signals.length;
  const breachBonus = signals.filter((s) => s.threshold_breached).length * 10;
  const compositeStress = Math.min(
    Math.round(avgStrength * 80 + breachBonus),
    100
  );

  return {
    composite_stress: compositeStress,
    signals,
    any_threshold_breached: signals.some((s) => s.threshold_breached),
  };
}
