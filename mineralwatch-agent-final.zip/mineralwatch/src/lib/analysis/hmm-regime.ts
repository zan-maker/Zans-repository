/**
 * Hidden Markov Model regime detection for commodity prices.
 *
 * Simplified 3-state model:
 *   State 0: Low-volatility (normal trading)
 *   State 1: Trending (directional move)
 *   State 2: Crisis (high-volatility disruption)
 *
 * Uses log-returns and rolling volatility as features.
 * Transition detection triggers alerts.
 */

export type RegimeState = "low_volatility" | "trending" | "crisis";

export interface RegimeResult {
  current_state: RegimeState;
  state_index: number;
  transition_detected: boolean;
  previous_state: RegimeState | null;
  confidence: number;
  volatility: number;
  observation_count: number;
}

const STATE_LABELS: RegimeState[] = ["low_volatility", "trending", "crisis"];

// Volatility thresholds for simple regime classification
// In production, these would be learned via Baum-Welch
const VOLATILITY_THRESHOLDS = {
  low_to_trending: 0.20, // Annualized vol threshold
  trending_to_crisis: 0.45,
};

/**
 * Detect the current price regime based on rolling volatility.
 *
 * @param prices - Array of prices, most recent first
 * @param windowDays - Rolling window for volatility calculation
 * @param previousState - Last known state (for transition detection)
 */
export function detectRegime(
  prices: number[],
  windowDays: number = 60,
  previousState?: RegimeState
): RegimeResult {
  if (prices.length < 2) {
    return {
      current_state: "low_volatility",
      state_index: 0,
      transition_detected: false,
      previous_state: previousState || null,
      confidence: 0,
      volatility: 0,
      observation_count: prices.length,
    };
  }

  // Calculate log returns
  const window = Math.min(windowDays, prices.length - 1);
  const logReturns: number[] = [];
  for (let i = 0; i < window; i++) {
    if (prices[i] > 0 && prices[i + 1] > 0) {
      logReturns.push(Math.log(prices[i] / prices[i + 1]));
    }
  }

  if (logReturns.length === 0) {
    return {
      current_state: "low_volatility",
      state_index: 0,
      transition_detected: false,
      previous_state: previousState || null,
      confidence: 0,
      volatility: 0,
      observation_count: prices.length,
    };
  }

  // Calculate annualized volatility
  const mean = logReturns.reduce((a, b) => a + b, 0) / logReturns.length;
  const variance =
    logReturns.reduce((sum, r) => sum + (r - mean) ** 2, 0) /
    (logReturns.length - 1);
  const annualizedVol = Math.sqrt(variance) * Math.sqrt(252);

  // Classify regime
  let stateIndex: number;
  let confidence: number;

  if (annualizedVol < VOLATILITY_THRESHOLDS.low_to_trending) {
    stateIndex = 0;
    confidence =
      1 - annualizedVol / VOLATILITY_THRESHOLDS.low_to_trending;
  } else if (annualizedVol < VOLATILITY_THRESHOLDS.trending_to_crisis) {
    stateIndex = 1;
    const range =
      VOLATILITY_THRESHOLDS.trending_to_crisis -
      VOLATILITY_THRESHOLDS.low_to_trending;
    const position =
      annualizedVol - VOLATILITY_THRESHOLDS.low_to_trending;
    confidence = 1 - Math.abs(position / range - 0.5) * 2;
  } else {
    stateIndex = 2;
    confidence = Math.min(
      (annualizedVol - VOLATILITY_THRESHOLDS.trending_to_crisis) / 0.2,
      1
    );
  }

  const currentState = STATE_LABELS[stateIndex];
  const transitionDetected =
    previousState !== undefined && previousState !== currentState;

  return {
    current_state: currentState,
    state_index: stateIndex,
    transition_detected: transitionDetected,
    previous_state: previousState || null,
    confidence: Math.round(confidence * 100) / 100,
    volatility: Math.round(annualizedVol * 10000) / 10000,
    observation_count: logReturns.length,
  };
}
