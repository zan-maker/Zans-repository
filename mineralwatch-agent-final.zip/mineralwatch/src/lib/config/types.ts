export interface MineralConfig {
  name: string;
  display_name: string;
  alpha_vantage_symbol: string;
  unit: string;
  alert_thresholds: {
    price_drop_pct: number;
    price_spike_pct: number;
    volatility_60d: number;
  };
}

export interface TrackedCompany {
  ticker: string;
  name: string;
}

export interface MacroIndicator {
  series_id: string;
  name: string;
  alert_threshold_pct_change?: number;
  alert_threshold_value?: number;
}

export interface RegulatoryMilestone {
  policy: string;
  milestone: string;
  date: string;
  estimated_impact: "high" | "medium" | "low";
}

export interface ScoringWeights {
  price_volatility_weight: number;
  macro_stress_weight: number;
  regulatory_impact_weight: number;
  concentration_risk_weight: number;
  demand_signal_weight: number;
}

export interface AgentConfig {
  minerals: MineralConfig[];
  tracked_companies: TrackedCompany[];
  macro_indicators: MacroIndicator[];
  regulatory_timeline: RegulatoryMilestone[];
  scoring: ScoringWeights;
  regime_detection: {
    n_states: number;
    window_days: number;
    min_observations: number;
  };
  alerts: {
    triggers: string[];
    cooldown_hours: number;
  };
  digest: {
    day_of_week: string;
    lookback_days: number;
  };
}
