import { tool } from "ai";
import { z } from "zod";
import { Client } from "@notionhq/client";
import { withNotion, getNotionAccessToken } from "../auth0-ai";

/**
 * Get a Notion client authenticated via Token Vault.
 */
async function getNotionClient(): Promise<Client> {
  const accessToken = await getNotionAccessToken();
  return new Client({ auth: accessToken });
}

/**
 * Tool: createNotionAlert
 * Auth: Token Vault (Notion)
 *
 * Creates a risk alert entry in the Notion Risk Alerts database.
 * Each alert is a rich page with a Gemini-generated context summary.
 */
export const createNotionAlert = withNotion(
  tool({
    description:
      "Create a risk alert entry in the Notion Risk Alerts database. " +
      "Used when the agent detects a regime transition, macro threshold breach, " +
      "or material regulatory filing.",
    parameters: z.object({
      database_id: z
        .string()
        .describe("Notion database ID for Risk Alerts"),
      mineral: z.string().describe("Affected mineral"),
      severity: z
        .enum(["Critical", "High", "Medium", "Low"])
        .describe("Alert severity level"),
      trigger_type: z
        .enum([
          "hmm_regime_transition",
          "macro_threshold_breach",
          "regulatory_filing_flagged",
          "price_threshold_breach",
        ])
        .describe("What triggered the alert"),
      summary: z
        .string()
        .describe("Gemini-generated context summary of the alert"),
      risk_score: z.number().describe("Current composite risk score (0-100)"),
    }),
    execute: async (params) => {
      try {
        const notion = await getNotionClient();
        const today = new Date().toISOString().split("T")[0];

        const page = await notion.pages.create({
          parent: { database_id: params.database_id },
          properties: {
            Name: {
              title: [
                {
                  text: {
                    content: `${params.severity}: ${params.mineral} — ${params.trigger_type.replace(/_/g, " ")}`,
                  },
                },
              ],
            },
            Date: { date: { start: today } },
            Mineral: { select: { name: params.mineral } },
            Severity: { select: { name: params.severity } },
            "Trigger Type": {
              select: { name: params.trigger_type.replace(/_/g, " ") },
            },
            "Risk Score": { number: params.risk_score },
          },
          children: [
            {
              object: "block",
              type: "heading_2",
              heading_2: {
                rich_text: [{ type: "text", text: { content: "Alert Summary" } }],
              },
            },
            {
              object: "block",
              type: "paragraph",
              paragraph: {
                rich_text: [
                  { type: "text", text: { content: params.summary } },
                ],
              },
            },
            {
              object: "block",
              type: "divider",
              divider: {},
            },
            {
              object: "block",
              type: "heading_3",
              heading_3: {
                rich_text: [{ type: "text", text: { content: "Details" } }],
              },
            },
            {
              object: "block",
              type: "bulleted_list_item",
              bulleted_list_item: {
                rich_text: [
                  {
                    type: "text",
                    text: {
                      content: `Mineral: ${params.mineral}`,
                    },
                  },
                ],
              },
            },
            {
              object: "block",
              type: "bulleted_list_item",
              bulleted_list_item: {
                rich_text: [
                  {
                    type: "text",
                    text: {
                      content: `Risk Score: ${params.risk_score}/100`,
                    },
                  },
                ],
              },
            },
            {
              object: "block",
              type: "bulleted_list_item",
              bulleted_list_item: {
                rich_text: [
                  {
                    type: "text",
                    text: {
                      content: `Trigger: ${params.trigger_type.replace(/_/g, " ")}`,
                    },
                  },
                ],
              },
            },
            {
              object: "block",
              type: "bulleted_list_item",
              bulleted_list_item: {
                rich_text: [
                  {
                    type: "text",
                    text: { content: `Date: ${today}` },
                  },
                ],
              },
            },
          ],
        });

        return {
          success: true,
          page_id: page.id,
          message: `Created ${params.severity} alert for ${params.mineral}`,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    },
  })
);
