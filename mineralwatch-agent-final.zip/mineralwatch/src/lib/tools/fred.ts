import { tool } from "ai";
import { z } from "zod";

/**
 * Tool: fetchFREDData
 * Auth: API key (not Token Vault — public data)
 *
 * Fetches macro indicator time series from the FRED API.
 */
export const fetchFREDData = tool({
  description:
    "Fetch macroeconomic indicator data from the FRED API. " +
    "Returns time series for indicators like PPI metals, industrial production, " +
    "PMI, and yield curve spread.",
  parameters: z.object({
    series_id: z
      .string()
      .describe("FRED series ID, e.g. 'INDPRO' for Industrial Production"),
    observation_start: z
      .string()
      .optional()
      .describe("Start date (YYYY-MM-DD). Defaults to 1 year ago."),
    observation_end: z
      .string()
      .optional()
      .describe("End date (YYYY-MM-DD). Defaults to today."),
  }),
  execute: async (params) => {
    const apiKey = process.env.FRED_API_KEY!;

    const now = new Date();
    const oneYearAgo = new Date(now);
    oneYearAgo.setFullYear(now.getFullYear() - 1);

    const start =
      params.observation_start || oneYearAgo.toISOString().split("T")[0];
    const end = params.observation_end || now.toISOString().split("T")[0];

    try {
      const url = new URL("https://api.stlouisfed.org/fred/series/observations");
      url.searchParams.set("series_id", params.series_id);
      url.searchParams.set("api_key", apiKey);
      url.searchParams.set("file_type", "json");
      url.searchParams.set("observation_start", start);
      url.searchParams.set("observation_end", end);
      url.searchParams.set("sort_order", "desc");

      const response = await fetch(url.toString());

      if (!response.ok) {
        throw new Error(`FRED API error: ${response.status}`);
      }

      const data = await response.json();
      const observations = data.observations
        .filter((obs: any) => obs.value !== ".")
        .slice(0, 24) // Last 24 observations (monthly = 2 years)
        .map((obs: any) => ({
          date: obs.date,
          value: parseFloat(obs.value),
        }));

      // Calculate latest month-over-month change
      const latest = observations[0]?.value;
      const previous = observations[1]?.value;
      const pctChange =
        latest && previous ? ((latest - previous) / previous) * 100 : null;

      return {
        success: true,
        series_id: params.series_id,
        latest_value: latest,
        latest_date: observations[0]?.date,
        pct_change_mom: pctChange ? Math.round(pctChange * 100) / 100 : null,
        observations_count: observations.length,
        observations: observations.slice(0, 6), // Return recent 6 for context
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  },
});
