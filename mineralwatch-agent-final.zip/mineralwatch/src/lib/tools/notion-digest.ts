import { tool } from "ai";
import { z } from "zod";
import { Client } from "@notionhq/client";
import { withNotion, getNotionAccessToken } from "../auth0-ai";

/**
 * Tool: createNotionDigest
 * Auth: Token Vault (Notion)
 *
 * Generates a formatted weekly digest page in Notion with price trends,
 * risk score movement, regulatory developments, and forward outlook.
 */
export const createNotionDigest = withNotion(
  tool({
    description:
      "Generate a formatted weekly digest page in Notion. " +
      "Contains price trends, risk score changes, regulatory updates, " +
      "and a forward-looking outlook narrative.",
    parameters: z.object({
      parent_page_id: z.string().describe("Notion parent page ID for digests"),
      week_label: z
        .string()
        .describe("Week label, e.g. 'Week of Mar 3, 2026'"),
      top_mover: z
        .string()
        .describe("Mineral with the largest price/risk movement"),
      risk_direction: z
        .enum(["increasing", "stable", "decreasing"])
        .describe("Overall risk trend direction"),
      price_summary: z
        .string()
        .describe("Gemini-generated summary of price movements"),
      regulatory_summary: z
        .string()
        .describe("Gemini-generated summary of regulatory developments"),
      outlook: z
        .string()
        .describe("Gemini-generated forward-looking outlook"),
      mineral_scores: z
        .array(
          z.object({
            mineral: z.string(),
            risk_score: z.number(),
            change: z.number(),
            regime: z.string(),
          })
        )
        .describe("Current risk scores for each monitored mineral"),
    }),
    execute: async (params) => {
      try {
        const accessToken = await getNotionAccessToken();
        const notion = new Client({ auth: accessToken });

        // Build the score summary table as text blocks
        const scoreBlocks = params.mineral_scores.map((m) => ({
          object: "block" as const,
          type: "bulleted_list_item" as const,
          bulleted_list_item: {
            rich_text: [
              {
                type: "text" as const,
                text: {
                  content: `${m.mineral}: ${m.risk_score}/100 (${m.change >= 0 ? "+" : ""}${m.change}) — ${m.regime}`,
                },
              },
            ],
          },
        }));

        const page = await notion.pages.create({
          parent: { page_id: params.parent_page_id },
          properties: {
            title: [
              {
                text: {
                  content: `Weekly Digest — ${params.week_label}`,
                },
              },
            ],
          },
          icon: { emoji: "📊" },
          children: [
            {
              object: "block",
              type: "callout",
              callout: {
                icon: { emoji: "⚡" },
                rich_text: [
                  {
                    type: "text",
                    text: {
                      content: `Top mover: ${params.top_mover} | Risk trend: ${params.risk_direction}`,
                    },
                  },
                ],
              },
            },
            {
              object: "block",
              type: "heading_2",
              heading_2: {
                rich_text: [
                  { type: "text", text: { content: "Risk Scores" } },
                ],
              },
            },
            ...scoreBlocks,
            {
              object: "block",
              type: "divider",
              divider: {},
            },
            {
              object: "block",
              type: "heading_2",
              heading_2: {
                rich_text: [
                  { type: "text", text: { content: "Price Movements" } },
                ],
              },
            },
            {
              object: "block",
              type: "paragraph",
              paragraph: {
                rich_text: [
                  { type: "text", text: { content: params.price_summary } },
                ],
              },
            },
            {
              object: "block",
              type: "heading_2",
              heading_2: {
                rich_text: [
                  {
                    type: "text",
                    text: { content: "Regulatory Developments" },
                  },
                ],
              },
            },
            {
              object: "block",
              type: "paragraph",
              paragraph: {
                rich_text: [
                  {
                    type: "text",
                    text: { content: params.regulatory_summary },
                  },
                ],
              },
            },
            {
              object: "block",
              type: "heading_2",
              heading_2: {
                rich_text: [
                  { type: "text", text: { content: "Forward Outlook" } },
                ],
              },
            },
            {
              object: "block",
              type: "paragraph",
              paragraph: {
                rich_text: [
                  { type: "text", text: { content: params.outlook } },
                ],
              },
            },
          ],
        });

        return {
          success: true,
          page_id: page.id,
          message: `Created weekly digest for ${params.week_label}`,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    },
  })
);
