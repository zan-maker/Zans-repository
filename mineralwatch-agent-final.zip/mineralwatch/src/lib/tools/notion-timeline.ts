import { tool } from "ai";
import { z } from "zod";
import { Client } from "@notionhq/client";
import { withNotion, getNotionAccessToken } from "../auth0-ai";

/**
 * Tool: updateRegulatoryTimeline
 * Auth: Token Vault (Notion)
 *
 * Creates or updates entries in the Notion Regulatory Timeline database.
 */
export const updateRegulatoryTimeline = withNotion(
  tool({
    description:
      "Update the regulatory timeline database in Notion with policy milestones, " +
      "days-until-deadline, and estimated market impact.",
    parameters: z.object({
      database_id: z
        .string()
        .describe("Notion database ID for Regulatory Timeline"),
      milestones: z.array(
        z.object({
          policy: z.string().describe("Policy name, e.g. 'FEOC Battery Ban'"),
          milestone: z.string().describe("Milestone description"),
          date: z.string().describe("Target date (YYYY-MM-DD)"),
          days_until: z.number().describe("Days until this milestone"),
          estimated_impact: z.enum(["high", "medium", "low"]),
          status: z
            .enum(["upcoming", "imminent", "effective", "passed"])
            .describe("Current status"),
        })
      ),
    }),
    execute: async (params) => {
      try {
        const accessToken = await getNotionAccessToken();
        const notion = new Client({ auth: accessToken });
        const results = [];

        for (const ms of params.milestones) {
          const page = await notion.pages.create({
            parent: { database_id: params.database_id },
            properties: {
              Name: {
                title: [{ text: { content: `${ms.policy}: ${ms.milestone}` } }],
              },
              Policy: { select: { name: ms.policy } },
              Date: { date: { start: ms.date } },
              "Days Until": { number: ms.days_until },
              Impact: { select: { name: ms.estimated_impact } },
              Status: { select: { name: ms.status } },
            },
          });
          results.push({ policy: ms.policy, page_id: page.id });
        }

        return {
          success: true,
          entries_created: results.length,
          results,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    },
  })
);
