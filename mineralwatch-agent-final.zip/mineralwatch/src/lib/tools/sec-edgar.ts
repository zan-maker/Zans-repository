import { tool } from "ai";
import { z } from "zod";

const SEC_USER_AGENT = "MineralWatch-Agent admin@example.com";

/**
 * Tool: fetchSECFilings
 * Auth: None required (public API, user-agent header only)
 *
 * Fetches recent 10-K/10-Q filings from SEC EDGAR for tracked companies.
 * Returns filing metadata and extracted text excerpts for NLP analysis.
 */
export const fetchSECFilings = tool({
  description:
    "Fetch recent SEC filings (10-K, 10-Q) for a given company ticker. " +
    "Returns filing metadata and text excerpts for regulatory NLP analysis.",
  parameters: z.object({
    ticker: z.string().describe("Company ticker symbol, e.g. 'TSLA'"),
    filing_type: z
      .enum(["10-K", "10-Q"])
      .optional()
      .describe("Filing type. Defaults to both."),
    max_filings: z
      .number()
      .optional()
      .describe("Maximum filings to return. Defaults to 3."),
  }),
  execute: async (params) => {
    const maxFilings = params.max_filings || 3;

    try {
      // Step 1: Get company CIK from ticker
      const tickerResponse = await fetch(
        "https://www.sec.gov/files/company_tickers.json",
        { headers: { "User-Agent": SEC_USER_AGENT } }
      );

      if (!tickerResponse.ok) {
        throw new Error(`SEC ticker lookup error: ${tickerResponse.status}`);
      }

      const tickers = await tickerResponse.json();
      const company = Object.values(tickers).find(
        (t: any) => t.ticker.toUpperCase() === params.ticker.toUpperCase()
      ) as any;

      if (!company) {
        return {
          success: false,
          error: `Ticker ${params.ticker} not found in SEC database`,
        };
      }

      const cik = String(company.cik_str).padStart(10, "0");

      // Step 2: Get recent filings
      const filingsUrl = `https://data.sec.gov/submissions/CIK${cik}.json`;
      const filingsResponse = await fetch(filingsUrl, {
        headers: { "User-Agent": SEC_USER_AGENT },
      });

      if (!filingsResponse.ok) {
        throw new Error(`SEC filings error: ${filingsResponse.status}`);
      }

      const filingsData = await filingsResponse.json();
      const recent = filingsData.filings.recent;

      // Filter by filing type
      const filings = [];
      for (let i = 0; i < recent.form.length && filings.length < maxFilings; i++) {
        const form = recent.form[i];
        if (
          !params.filing_type ||
          form === params.filing_type ||
          (!params.filing_type && (form === "10-K" || form === "10-Q"))
        ) {
          filings.push({
            form: recent.form[i],
            filing_date: recent.filingDate[i],
            accession_number: recent.accessionNumber[i],
            primary_document: recent.primaryDocument[i],
            description: recent.primaryDocDescription[i],
          });
        }
      }

      // Step 3: Fetch first filing's text for NLP (limited excerpt)
      let filing_text_excerpt = null;
      if (filings.length > 0) {
        const accession = filings[0].accession_number.replace(/-/g, "");
        const docUrl = `https://www.sec.gov/Archives/edgar/data/${parseInt(cik)}/${accession}/${filings[0].primary_document}`;

        try {
          const docResponse = await fetch(docUrl, {
            headers: { "User-Agent": SEC_USER_AGENT },
          });

          if (docResponse.ok) {
            const fullText = await docResponse.text();
            // Extract text, strip HTML, take first 5000 chars for NLP
            const plainText = fullText
              .replace(/<[^>]*>/g, " ")
              .replace(/\s+/g, " ")
              .trim()
              .slice(0, 5000);
            filing_text_excerpt = plainText;
          }
        } catch {
          // Non-critical: filing text extraction is best-effort
        }
      }

      return {
        success: true,
        ticker: params.ticker,
        company_name: company.title,
        cik: cik,
        filings_found: filings.length,
        filings,
        filing_text_excerpt,
      };
    } catch (error) {
      return {
        success: false,
        ticker: params.ticker,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  },
});
