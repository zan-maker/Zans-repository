import { tool } from "ai";
import { z } from "zod";

/**
 * Tool: fetchCommodityPrices
 * Auth: API key (not Token Vault — public data)
 *
 * Fetches commodity price data from Alpha Vantage.
 * Returns daily prices and calculates rolling volatility.
 */
export const fetchCommodityPrices = tool({
  description:
    "Fetch daily commodity price data from Alpha Vantage. " +
    "Returns recent prices and calculated 60-day rolling volatility " +
    "for battery minerals (lithium, nickel, cobalt, manganese).",
  parameters: z.object({
    commodity: z
      .string()
      .describe("Commodity name: lithium, nickel, cobalt, or manganese"),
    function_type: z
      .string()
      .optional()
      .describe(
        "Alpha Vantage function. Defaults to commodity-appropriate endpoint."
      ),
  }),
  execute: async (params) => {
    const apiKey = process.env.ALPHA_VANTAGE_API_KEY!;

    // Map commodities to Alpha Vantage endpoints
    const commodityMap: Record<string, { function: string; symbol?: string }> = {
      lithium: { function: "TIME_SERIES_DAILY", symbol: "ALB" }, // Proxy via Albemarle
      nickel: { function: "NICKEL", symbol: undefined },
      cobalt: { function: "TIME_SERIES_DAILY", symbol: "VALE" }, // Proxy via Vale
      manganese: { function: "TIME_SERIES_DAILY", symbol: "BHP" }, // Proxy via BHP
    };

    const config = commodityMap[params.commodity.toLowerCase()] || {
      function: "TIME_SERIES_DAILY",
      symbol: params.commodity,
    };

    try {
      const url = new URL("https://www.alphavantage.co/query");
      url.searchParams.set("function", config.function);
      if (config.symbol) url.searchParams.set("symbol", config.symbol);
      url.searchParams.set("apikey", apiKey);
      url.searchParams.set("outputsize", "compact");

      const response = await fetch(url.toString());

      if (!response.ok) {
        throw new Error(`Alpha Vantage API error: ${response.status}`);
      }

      const data = await response.json();

      // Parse time series data
      const timeSeriesKey = Object.keys(data).find((k) =>
        k.includes("Time Series")
      );

      if (!timeSeriesKey) {
        // Handle commodity-specific endpoints (e.g., NICKEL)
        if (data.data) {
          const prices = data.data.slice(0, 60).map((d: any) => ({
            date: d.date,
            price: parseFloat(d.value),
          }));
          return formatPriceResponse(params.commodity, prices);
        }
        throw new Error("Unexpected API response format");
      }

      const timeSeries = data[timeSeriesKey];
      const dates = Object.keys(timeSeries).sort().reverse().slice(0, 60);
      const prices = dates.map((date) => ({
        date,
        price: parseFloat(timeSeries[date]["4. close"]),
      }));

      return formatPriceResponse(params.commodity, prices);
    } catch (error) {
      return {
        success: false,
        commodity: params.commodity,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  },
});

function formatPriceResponse(
  commodity: string,
  prices: { date: string; price: number }[]
) {
  if (prices.length === 0) {
    return { success: false, commodity, error: "No price data returned" };
  }

  const latest = prices[0];
  const previous = prices[1];
  const dailyChange =
    previous
      ? ((latest.price - previous.price) / previous.price) * 100
      : null;

  // Calculate 60-day rolling volatility (annualized)
  const logReturns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    if (prices[i].price > 0 && prices[i - 1].price > 0) {
      logReturns.push(Math.log(prices[i - 1].price / prices[i].price));
    }
  }

  const mean = logReturns.reduce((a, b) => a + b, 0) / logReturns.length;
  const variance =
    logReturns.reduce((sum, r) => sum + (r - mean) ** 2, 0) /
    (logReturns.length - 1);
  const volatility60d = Math.sqrt(variance) * Math.sqrt(252); // Annualized

  return {
    success: true,
    commodity,
    latest_price: latest.price,
    latest_date: latest.date,
    daily_change_pct: dailyChange
      ? Math.round(dailyChange * 100) / 100
      : null,
    volatility_60d: Math.round(volatility60d * 10000) / 10000,
    prices_count: prices.length,
    recent_prices: prices.slice(0, 5),
  };
}
