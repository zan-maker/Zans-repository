import { tool } from "ai";
import { z } from "zod";
import { withGoogleSheets, getGoogleSheetsAccessToken } from "../auth0-ai";

/**
 * Tool: appendToSheet
 * Auth: Token Vault (Google)
 *
 * Appends a row of price/risk data to the user's Google Sheet.
 * Token Vault handles the OAuth token exchange — no service account keys.
 */
export const appendToSheet = withGoogleSheets(
  tool({
    description:
      "Append a row of commodity price and risk score data to the Google Sheet. " +
      "Each row contains: date, mineral, price, volatility, risk score, regime, " +
      "and macro indicators.",
    parameters: z.object({
      date: z.string().describe("ISO date string (YYYY-MM-DD)"),
      mineral: z.string().describe("Mineral name"),
      price_usd: z.number().describe("Current price in USD"),
      volatility_60d: z.number().describe("60-day rolling volatility"),
      risk_score: z.number().describe("Composite risk score (0-100)"),
      regime: z
        .enum(["low_volatility", "trending", "crisis"])
        .describe("Current HMM regime"),
      ppi_metals: z.number().optional().describe("PPI metals index value"),
      pmi: z.number().optional().describe("PMI value"),
      yield_spread: z
        .number()
        .optional()
        .describe("10Y-2Y treasury spread"),
    }),
    execute: async (params) => {
      const accessToken = await getGoogleSheetsAccessToken();
      const sheetId = process.env.GOOGLE_SHEET_ID!;

      const row = [
        params.date,
        params.mineral,
        params.price_usd,
        params.volatility_60d,
        params.risk_score,
        params.regime,
        params.ppi_metals ?? "",
        params.pmi ?? "",
        params.yield_spread ?? "",
      ];

      try {
        const response = await fetch(
          `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Sheet1:append?valueInputOption=USER_ENTERED`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${accessToken}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              values: [row],
            }),
          }
        );

        if (!response.ok) {
          throw new Error(
            `Sheets API error: ${response.status} ${response.statusText}`
          );
        }

        const result = await response.json();

        return {
          success: true,
          updated_range: result.updates?.updatedRange,
          message: `Appended ${params.mineral} data for ${params.date}`,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    },
  })
);
