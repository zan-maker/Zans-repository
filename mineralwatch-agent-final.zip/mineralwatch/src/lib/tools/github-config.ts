import { tool } from "ai";
import { z } from "zod";
import yaml from "js-yaml";
import { withGitHub, getGitHubAccessToken } from "../auth0-ai";
import type { AgentConfig } from "../config/types";

/**
 * Tool: readGitHubConfig
 * Auth: Token Vault (GitHub)
 *
 * Reads the agent configuration YAML from a private GitHub repo.
 * Token Vault handles the OAuth token exchange — we never see a PAT.
 */
export const readGitHubConfig = withGitHub(
  tool({
    description:
      "Read the agent configuration file from the GitHub config repository. " +
      "Returns alert thresholds, monitored minerals, tracked companies, " +
      "regulatory milestones, and scoring weights.",
    parameters: z.object({}),
    execute: async () => {
      const accessToken = await getGitHubAccessToken();
      const repo = process.env.GITHUB_CONFIG_REPO!;
      const path = process.env.GITHUB_CONFIG_PATH || "config.yaml";

      try {
        const response = await fetch(
          `https://api.github.com/repos/${repo}/contents/${path}`,
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
              Accept: "application/vnd.github.v3.raw",
              "User-Agent": "MineralWatch-Agent",
            },
          }
        );

        if (!response.ok) {
          throw new Error(
            `GitHub API error: ${response.status} ${response.statusText}`
          );
        }

        const content = await response.text();
        const config = yaml.load(content) as AgentConfig;

        return {
          success: true,
          config,
          minerals_count: config.minerals.length,
          companies_count: config.tracked_companies.length,
          milestones_count: config.regulatory_timeline.length,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    },
  })
);
