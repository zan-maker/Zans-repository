import { Auth0Client } from "@auth0/nextjs-auth0/server";

export const auth0 = new Auth0Client();

/**
 * Get the current user's Auth0 refresh token.
 * Used by Token Vault to exchange for provider-specific access tokens.
 */
export const getRefreshToken = async (): Promise<string | undefined> => {
  const session = await auth0.getSession();
  return session?.tokenSet?.refreshToken;
};

/**
 * Get the current user's session.
 */
export const getSession = async () => {
  return auth0.getSession();
};
