import { Auth0AI, getAccessTokenForConnection } from "@auth0/ai-vercel";
import { getRefreshToken } from "./auth0";

const auth0AI = new Auth0AI();

// =============================================================================
// Token Vault Connection #1: GitHub
// Purpose: Read agent configuration from private repo
// Scopes: repo (read access to private repos)
// =============================================================================
export const withGitHub = auth0AI.withTokenForConnection({
  connection: "github",
  scopes: ["repo"],
  refreshToken: getRefreshToken,
});

export const getGitHubAccessToken = async () => getAccessTokenForConnection();

// =============================================================================
// Token Vault Connection #2: Google Sheets
// Purpose: Write daily price data and risk scores
// Scopes: spreadsheets (read/write access to user's sheets)
// =============================================================================
export const withGoogleSheets = auth0AI.withTokenForConnection({
  connection: "google-oauth2",
  scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  refreshToken: getRefreshToken,
});

export const getGoogleSheetsAccessToken = async () =>
  getAccessTokenForConnection();

// =============================================================================
// Token Vault Connection #3: Notion
// Purpose: Create risk alerts, weekly digests, and regulatory timeline entries
// Scopes: Notion OAuth grants access to pages selected during consent
// =============================================================================
export const withNotion = auth0AI.withTokenForConnection({
  connection: "notion",
  scopes: [],
  refreshToken: getRefreshToken,
});

export const getNotionAccessToken = async () => getAccessTokenForConnection();
