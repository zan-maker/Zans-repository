"use client";

import { useChat } from "ai/react";
import { useState } from "react";

export default function Home() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } =
    useChat({ api: "/api/chat" });
  const [showSetup, setShowSetup] = useState(false);

  const quickActions = [
    {
      label: "Run full scan",
      prompt: "Read my config from GitHub, pull latest prices for all minerals, check FRED macro indicators, and report any risk alerts. Write data to my Google Sheet and create Notion alerts for any threshold breaches.",
    },
    {
      label: "Lithium risk check",
      prompt: "What is the current lithium carbonate risk score? Pull the latest price, check volatility regime, and summarize the top risk drivers.",
    },
    {
      label: "Regulatory update",
      prompt: "Check the latest SEC filings from Tesla and Albemarle for any FEOC or IRA regulatory language. Classify and summarize findings.",
    },
    {
      label: "Weekly digest",
      prompt: "Generate a weekly digest for Notion covering all monitored minerals: price movements, risk score changes, regulatory developments, and forward outlook.",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-[#1b2f22] px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#2e7d32] flex items-center justify-center text-sm font-bold">
            MW
          </div>
          <div>
            <h1 className="text-lg font-semibold text-[#e8f5e9]">
              MineralWatch Agent
            </h1>
            <p className="text-xs text-[#81c784]">
              Critical Minerals Risk Intelligence
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex gap-2">
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs bg-[#162019] border border-[#1b2f22] text-[#81c784]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4caf50]" />
              GitHub
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs bg-[#162019] border border-[#1b2f22] text-[#81c784]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4caf50]" />
              Sheets
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs bg-[#162019] border border-[#1b2f22] text-[#81c784]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4caf50]" />
              Notion
            </span>
          </div>
          <a
            href="/api/auth/login"
            className="px-3 py-1.5 rounded text-xs font-medium bg-[#2e7d32] text-white hover:bg-[#388e3c] transition"
          >
            Login
          </a>
        </div>
      </header>

      <div className="flex-1 flex">
        {/* Sidebar: Quick Actions */}
        <aside className="w-64 border-r border-[#1b2f22] p-4 hidden md:block">
          <h2 className="text-xs font-semibold text-[#81c784] uppercase tracking-wider mb-3">
            Quick Actions
          </h2>
          <div className="space-y-2">
            {quickActions.map((action, i) => (
              <button
                key={i}
                onClick={() => {
                  const fakeEvent = {
                    target: { value: action.prompt },
                  } as React.ChangeEvent<HTMLInputElement>;
                  handleInputChange(fakeEvent);
                  setTimeout(() => {
                    const form = document.querySelector("form");
                    form?.requestSubmit();
                  }, 50);
                }}
                className="w-full text-left px-3 py-2.5 rounded-lg text-sm bg-[#162019] border border-[#1b2f22] text-[#e8f5e9] hover:border-[#2e7d32] hover:bg-[#1a2b1f] transition"
              >
                {action.label}
              </button>
            ))}
          </div>

          <div className="mt-6 pt-4 border-t border-[#1b2f22]">
            <h2 className="text-xs font-semibold text-[#81c784] uppercase tracking-wider mb-3">
              Auth Model
            </h2>
            <div className="space-y-2 text-xs text-[#81c784]">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#4caf50]" />
                Token Vault: GitHub, Sheets, Notion
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#ff9800]" />
                API Keys: FRED, Alpha Vantage, EDGAR
              </div>
            </div>
          </div>
        </aside>

        {/* Chat Interface */}
        <main className="flex-1 flex flex-col">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 && (
              <div className="flex-1 flex items-center justify-center min-h-[50vh]">
                <div className="text-center max-w-md">
                  <div className="w-16 h-16 rounded-2xl bg-[#162019] border border-[#1b2f22] flex items-center justify-center mx-auto mb-4 text-2xl">
                    🪨
                  </div>
                  <h2 className="text-xl font-semibold text-[#e8f5e9] mb-2">
                    MineralWatch Agent
                  </h2>
                  <p className="text-sm text-[#81c784] mb-6">
                    AI supply chain risk intelligence for critical minerals.
                    Secured by Auth0 Token Vault across GitHub, Google Sheets,
                    and Notion.
                  </p>
                  <p className="text-xs text-[#4a6b4f]">
                    Try a quick action from the sidebar, or ask me anything about
                    lithium, nickel, cobalt, or manganese supply chains.
                  </p>
                </div>
              </div>
            )}

            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-2xl rounded-xl px-4 py-3 text-sm leading-relaxed ${
                    msg.role === "user"
                      ? "bg-[#2e7d32] text-white"
                      : "bg-[#162019] border border-[#1b2f22] text-[#e8f5e9]"
                  }`}
                >
                  <pre className="whitespace-pre-wrap font-[inherit]">
                    {msg.content}
                  </pre>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-[#162019] border border-[#1b2f22] rounded-xl px-4 py-3 text-sm text-[#81c784]">
                  <span className="inline-flex gap-1">
                    <span className="animate-pulse">●</span>
                    <span className="animate-pulse" style={{ animationDelay: "0.2s" }}>●</span>
                    <span className="animate-pulse" style={{ animationDelay: "0.4s" }}>●</span>
                  </span>
                  {" "}Analyzing...
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="border-t border-[#1b2f22] p-4">
            <form onSubmit={handleSubmit} className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={handleInputChange}
                placeholder="Ask about mineral prices, risk scores, regulatory updates..."
                className="flex-1 bg-[#162019] border border-[#1b2f22] rounded-xl px-4 py-3 text-sm text-[#e8f5e9] placeholder-[#4a6b4f] focus:outline-none focus:border-[#2e7d32] transition"
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="px-6 py-3 rounded-xl text-sm font-medium bg-[#2e7d32] text-white hover:bg-[#388e3c] disabled:opacity-40 disabled:cursor-not-allowed transition"
              >
                Send
              </button>
            </form>
          </div>
        </main>
      </div>
    </div>
  );
}
