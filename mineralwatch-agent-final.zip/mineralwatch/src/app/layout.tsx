import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MineralWatch Agent",
  description:
    "AI-powered critical minerals supply chain risk intelligence — secured by Auth0 Token Vault",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#0a0f0d]">{children}</body>
    </html>
  );
}
