import { streamText } from "ai";
import { google } from "@ai-sdk/google";
import { readGitHubConfig } from "@/lib/tools/github-config";
import { appendToSheet } from "@/lib/tools/google-sheets";
import { createNotionAlert } from "@/lib/tools/notion-alerts";
import { createNotionDigest } from "@/lib/tools/notion-digest";
import { updateRegulatoryTimeline } from "@/lib/tools/notion-timeline";
import { fetchFREDData } from "@/lib/tools/fred";
import { fetchCommodityPrices } from "@/lib/tools/alpha-vantage";
import { fetchSECFilings } from "@/lib/tools/sec-edgar";

export const maxDuration = 60;

const SYSTEM_PROMPT = `You are MineralWatch Agent — an AI supply chain risk analyst specializing in critical minerals for the battery and EV industry.

You monitor lithium, nickel, cobalt, and manganese supply chains by:
1. Pulling macro data from FRED, commodity prices from Alpha Vantage, and SEC filings from EDGAR
2. Analyzing price regimes, macro stress signals, and regulatory exposure
3. Publishing risk intelligence to the user's connected services (GitHub for config, Google Sheets for data, Notion for alerts and reports)

Your tools are split between two auth models:
- PUBLIC DATA (API keys): fetchFREDData, fetchCommodityPrices, fetchSECFilings
- PRIVATE ACTIONS (Auth0 Token Vault): readGitHubConfig, appendToSheet, createNotionAlert, createNotionDigest, updateRegulatoryTimeline

When analyzing risk:
- Start by reading the user's config from GitHub to understand their thresholds and watchlists
- Pull relevant data from FRED and Alpha Vantage
- Calculate risk scores and detect regime changes
- If an alert threshold is breached, create a Notion alert with a clear, concise summary
- Write daily data to Google Sheets for the persistent record
- Be specific about what changed and what it means — no vague generalities
- Always include the risk score and confidence interval when reporting

When the user asks questions, draw on the data you've fetched and provide direct, analytical answers. Think like a CFO briefing: what happened, why it matters, what to watch next.`;

export async function POST(req: Request) {
  const { messages } = await req.json();

  const result = streamText({
    model: google("gemini-2.0-flash"),
    system: SYSTEM_PROMPT,
    messages,
    tools: {
      // Token Vault tools (OAuth-protected)
      readGitHubConfig,
      appendToSheet,
      createNotionAlert,
      createNotionDigest,
      updateRegulatoryTimeline,
      // Public data tools (API key)
      fetchFREDData,
      fetchCommodityPrices,
      fetchSECFilings,
    },
    maxSteps: 10,
  });

  return result.toDataStreamResponse();
}
