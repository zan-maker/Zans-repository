# Elevator Pitch

**AI agent that tracks critical mineral prices, detects supply disruptions, and publishes risk intelligence to Notion — secured by Auth0 Token Vault across GitHub, Sheets, and Notion.**

*(175 characters)*

---

# MineralWatch Agent

## Inspiration

The global battery supply chain runs on a handful of critical minerals — lithium, nickel, cobalt, manganese — concentrated in a few countries and subject to rapidly shifting trade policy. In the last three years, lithium carbonate swung from \$8/kg to \$80/kg and back. A single Indonesian producer nearly collapsed the nickel market. New regulation is rewriting the rules of who can source what from where.

The data to track this exists across public APIs — FRED for macro indicators, Alpha Vantage for commodity prices, SEC EDGAR for company filings — but raw data isn't intelligence. Teams need processed, contextualized risk assessments delivered where they actually work: versioned configuration in **GitHub**, structured data in **Google Sheets**, and rich searchable reports in **Notion**.

Building an AI agent that connects to all three means managing three separate OAuth integrations, three token lifecycles, three revocation paths. That's weeks of security plumbing with nothing to do with the intelligence layer.

Then I found Auth0's Token Vault. One SDK. Three connections. Scoped, consented, revocable access — and the agent code never touches a raw token. The entire auth complexity collapsed into configuration, and I could focus on the part that matters: making the risk intelligence smart.

The "Authorized to Act" hackathon was the forcing function to build a domain-specific agent that demonstrates Token Vault's multi-provider pattern on a real use case — one where AI pulls financial data, generates analysis, and *acts* across the user's connected tools under secure, user-controlled authorization.

---

## What it does

**MineralWatch Agent** generates a composite supply chain risk score for battery materials and publishes actionable intelligence across three OAuth-protected services — all secured by Auth0 Token Vault.

### Data Ingestion (Public APIs)

The agent pulls from three financial data sources using standard API keys:

- **FRED API** — macro indicators: PPI for metals, industrial production, yield curve spread, PMI
- **Alpha Vantage API** — daily commodity prices: lithium carbonate, nickel sulfate, cobalt hydroxide
- **SEC EDGAR API** — 10-K/10-Q filings from battery and EV companies

### AI Analysis (Google Gemini 2.0 Flash)

The agent processes raw data through three analytical layers:

**Price Regime Detection** — a Hidden Markov Model with 3 states (low-volatility, trending, crisis) fitted on rolling 60-day commodity log-returns. The transition matrix is estimated via Baum-Welch:

$$\hat{a}_{ij} = \frac{\sum_{t=1}^{T-1} \xi_t(i,j)}{\sum_{t=1}^{T-1} \gamma_t(i)}$$

**Macro Signal Correlation** — Granger causality tests linking leading indicators to 30/60/90-day commodity price movements, identifying which macro signals are predictive for which minerals.

**Regulatory NLP** — Gemini classifies SEC filing paragraphs by regulatory relevance (FEOC, IRA Section 45X, EU CRMA) and sentiment (risk/opportunity/neutral), producing a regulatory exposure score per company.

The **composite risk score** uses a weighted Bayesian ensemble:

$$P(\theta \mid D) \propto P(D \mid \theta) \cdot P(\theta)$$

Priors are set from historical disruption base rates (~2.3 major supply events per decade per mineral), posteriors update with each data pull.

### Secure Third-Party Actions (Auth0 Token Vault)

The agent acts across three OAuth-protected services — each connection managed by Token Vault:

**GitHub (Connection #1)** — reads agent configuration from a private repo: alert thresholds, monitored minerals, tracked companies, regulatory dates, scoring weights. Config is YAML — anyone on the team can update behavior by editing and committing. Version history provides full audit trail.

**Google Sheets (Connection #2)** — writes structured data: daily commodity prices, rolling volatility, macro snapshots, composite risk scores. Each run appends a row, building a persistent time series the team can chart, filter, and share.

**Notion (Connection #3)** — the primary intelligence output layer:
- **Risk Alert Database** — entries created when the HMM detects a regime transition, a macro threshold is breached, or Gemini flags a material regulatory filing. Each entry includes severity, mineral, trigger type, and a Gemini-generated context summary.
- **Weekly Digest Pages** — formatted Notion pages with price trends, risk score movement, regulatory developments, and forward outlook. Searchable intelligence archive.
- **Regulatory Timeline Database** — tracks upcoming policy milestones (FEOC enforcement, IRA credit phase-downs, EU CRMA deadlines) with days-until-deadline and estimated market impact.

### User Flow

```
1. Log in via Auth0 Universal Login
2. Token Vault prompts consent for GitHub, Sheets, Notion (progressively)
3. Agent reads config YAML from GitHub
4. Agent pulls FRED + Alpha Vantage + EDGAR data
5. Gemini analyzes: price regime, macro signals, regulatory NLP
6. Daily → appends price + risk row to Google Sheet
7. On trigger → creates Notion Risk Alert entry
8. Weekly → generates formatted Notion digest page
9. User can chat: "What's driving lithium risk this week?"
```

---

## How we built it

### Architecture

```
[Auth0 Universal Login] → [Token Vault]
                               ↓
                    ┌──────────┼──────────┐
                    ↓          ↓          ↓
               [GitHub]   [Google     [Notion]
               (config)    Sheets]    (alerts +
                          (data)      reports)
                               ↑
              [Vercel AI SDK + Gemini Agent]
                               ↑
                    ┌──────────┼──────────┐
                    ↓          ↓          ↓
               [FRED]   [Alpha       [SEC
               (macro)   Vantage]    EDGAR]
                         (prices)   (filings)
```

### Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 14 (App Router) |
| Auth | Auth0 (`@auth0/nextjs-auth0`) |
| Token Management | Auth0 Token Vault (`@auth0/ai-vercel`) |
| AI Framework | Vercel AI SDK |
| LLM | Google Gemini 2.0 Flash |
| Token Vault Connections | GitHub, Google Sheets, Notion |
| Public Data APIs | FRED, Alpha Vantage, SEC EDGAR |
| Deployment | Vercel |

### Token Vault — Three Connections

```typescript
const auth0AI = new Auth0AI();

// Connection 1: GitHub — read config from private repo
export const withGitHub = auth0AI.withTokenForConnection({
  connection: 'github',
  scopes: ['repo'],
  refreshToken: getRefreshToken,
});

// Connection 2: Google Sheets — write price data and risk scores
export const withGoogleSheets = auth0AI.withTokenForConnection({
  connection: 'google-oauth2',
  scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  refreshToken: getRefreshToken,
});

// Connection 3: Notion — create alerts and digest pages
export const withNotion = auth0AI.withTokenForConnection({
  connection: 'notion',
  scopes: [],  // Notion OAuth grants access to selected pages at consent
  refreshToken: getRefreshToken,
});
```

Each tool is wrapped with the corresponding `withTokenForConnection` helper. When the agent calls `createNotionAlert`, Token Vault exchanges the Auth0 refresh token for a fresh Notion access token automatically — zero manual token management in our code.

### Agent Tools

| Tool | Auth Model | Purpose |
|---|---|---|
| `fetchFREDData` | API key | Pull macro indicators |
| `fetchCommodityPrices` | API key | Pull daily mineral prices |
| `fetchSECFilings` | API key | Pull 10-K filing text |
| `readGitHubConfig` | Token Vault (GitHub) | Read thresholds and watchlist |
| `appendToSheet` | Token Vault (Sheets) | Write daily price + risk row |
| `createNotionAlert` | Token Vault (Notion) | Create risk alert database entry |
| `createNotionDigest` | Token Vault (Notion) | Generate weekly digest page |
| `updateRegulatoryTimeline` | Token Vault (Notion) | Update milestone database |
| `analyzeWithGemini` | API key | NLP classification + summarization |

**Design principle:** public data flows through API keys, private actions flow through Token Vault. The security boundary is explicit — you can audit exactly which tools require user consent.

### Notion Integration

Notion's OAuth grants access to specific pages the user selects during consent. On first run, the agent creates three databases as children of the user's shared parent page:

1. **Risk Alerts** — Date, Mineral, Severity, Trigger Type, Summary, Risk Score
2. **Weekly Digests** — Week, Top Mover, Risk Direction, Key Event, link to full page
3. **Regulatory Timeline** — Policy, Milestone, Date, Days Until, Impact, Status

Each alert and digest is a rich Notion page with formatted blocks — Gemini generates content in Notion's block structure for clean rendering.

---

## Challenges we ran into

**Three OAuth providers, three consent flows, one smooth UX.** Presenting three authorization prompts on first login is jarring. We implemented progressive connection: GitHub connects first (loads config, proves value), then Sheets and Notion connect when the agent first needs to write. Auth0's async authorization flow makes this pattern clean — the agent pauses, prompts consent, and resumes once granted.

**Notion's page-level permission model.** Unlike GitHub where you authorize repo-wide access, Notion lets the user select *which pages* to share. The agent can't create databases in arbitrary locations. We solved this by having the user share a single parent page — the agent creates all three databases as children. Clean containment with minimal permission surface.

**Mixing API-key and OAuth auth in a single agent turn.** The agent fetches FRED data (API key), analyzes with Gemini (API key), then writes to Sheets and Notion (Token Vault). We kept clean separation: data-fetching tools are plain functions, action tools are wrapped with `withTokenForConnection`. The Vercel AI SDK's tool composition handled this naturally.

**Making alerts high-signal, not noisy.** Early versions triggered on every price move. We implemented regime-based triggers: alerts fire only on HMM state transitions (e.g., low-vol $\rightarrow$ crisis), config-defined macro threshold breaches, or Gemini-classified material regulatory filings. Each alert includes a generated summary explaining *why* and *what it means* — not just raw numbers. Volume dropped ~80% while signal quality increased.

**Notion API rate limits on rich page creation.** Weekly digests with multiple formatted blocks require many API calls. We hit limits during testing. The fix: batch block creation into chunks of 100 (Notion's append limit) with exponential backoff, and pre-compose the full page structure before making any calls.

---

## Accomplishments that we're proud of

**Three Token Vault connections working in concert.** GitHub for config, Sheets for structured data, Notion for rich intelligence — each OAuth-protected, each independently revocable, each scoped to minimum permissions. This demonstrates the multi-provider pattern Token Vault is designed for, on a use case judges can immediately understand.

**Zero stored credentials in our codebase.** No GitHub PATs. No Google service account keys. No Notion integration secrets. Every third-party interaction goes through Token Vault. The only secrets in our environment are Auth0 credentials and API keys for public data sources.

**Config-as-code via Token Vault's GitHub connection.** Thresholds, watchlists, and scoring weights are version-controlled and editable by anyone on the team — without touching deployed code. Change a YAML value, commit, and the agent picks it up on next run.

**Notion as an intelligence platform.** Instead of flat text notifications, MineralWatch outputs filterable databases, formatted digest pages, and regulatory timelines. Judges can open the Notion workspace and *explore* the output — a far more compelling demo than a chat screenshot.

**Domain-specific intelligence, not a generic chatbot.** Every other submission will build "an AI assistant that connects to Notion." MineralWatch connects to Notion to deliver critical minerals supply chain risk intelligence powered by real-time macro and commodity data. The domain is the differentiator.

---

## What we learned

**Token Vault's multi-provider model is the right abstraction.** Production agents don't connect to one service — they connect to many, each for a different purpose. Token Vault's one-connection-per-provider model with scoped access per tool is how agent authorization should work. Building three OAuth integrations from scratch would have taken weeks; with Token Vault it took hours.

**Separating data ingestion from authorized actions is clean architecture.** Public data (FRED, Alpha Vantage, EDGAR) uses API keys. Private actions (GitHub reads, Sheet writes, Notion creates) use Token Vault. The security model becomes obvious and auditable.

**Progressive connection > upfront consent.** Three OAuth prompts before any value is a conversion killer. Connecting services as needed — GitHub first, then Sheets and Notion when the agent needs to write — builds trust incrementally. Auth0's async authorization makes this straightforward.

**Notion's permission model is underrated for agent output.** Users select exactly which pages to share. The agent can only write there. This gives granular, visible control over where AI content appears — better than most providers' all-or-nothing models.

**The identity layer determines what agents can do in production.** Gemini generates brilliant analysis, but without secure access to tools where teams work, that analysis dies in a chat window. Token Vault turns an analytical AI into an *operational* AI — delivering intelligence to the right place, in the right format, under the right authorization.

---

## What's next for MineralWatch Agent

**Scheduled automation** — Vercel Cron for daily data pulls and weekly digests, with Notion alerts created as triggers fire.

**Expanded connections** — Jira or Linear via Token Vault to auto-create compliance tickets on regulatory risk triggers. Microsoft 365 for teams on Outlook/SharePoint.

**GitHub write-back** — auto-create PRs when the agent detects new companies or milestones, updating the config YAML through Token Vault's GitHub connection for a full read-write loop.

**Auth0 FGA integration** — role-based Notion access: analysts see the full alert feed, executives get weekly digests only, compliance gets the regulatory timeline.

**Backtest mode** — *"Would this config have caught the 2022 lithium spike?"* — replay historical data through the current ruleset, generating a simulated Notion timeline.

**Multi-mineral scenario engine** — Monte Carlo simulation with $n = 10{,}000$ paths for user-defined price and policy shocks, with scenario comparison pages published to Notion.

---

## Built With

`Auth0`, `Token Vault`, `Next.js`, `Vercel AI SDK`, `Google Gemini API`, `Notion API`, `Google Sheets API`, `GitHub API`, `FRED API`, `Alpha Vantage API`, `SEC EDGAR API`, `TypeScript`, `Vercel`, `OAuth 2.0`, `RFC 8693 Token Exchange`, `Hidden Markov Models`, `Bayesian Statistics`

---

*Built with Auth0 Token Vault. Three providers, zero stored tokens.*
