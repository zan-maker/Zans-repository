# CritMin Compass — Sample Pipeline Output

Representative output from a full pipeline run.

---

## Block 1: FRED Macroeconomic Data

```
────────────────────────────────────────────────────
fred_df populated successfully
   Shape      : (73, 3)  (rows x columns)
   Date range : 2020-01-01 -> 2026-01-01
   Columns    : ['PPI', 'Industrial_Production', 'Trade_Balance']
   NaN count  : {'PPI': 0, 'Industrial_Production': 0, 'Trade_Balance': 0}
────────────────────────────────────────────────────

--- tail(5) preview ---
                  PPI  Industrial_Production  Trade_Balance
Date
2025-09-01  249.582              103.4901         -68023.0
2025-10-01  250.127              103.6211         -73615.0
2025-11-01  250.894              103.7453         -78191.0
2025-12-01  251.338              103.5892         -98042.0
2026-01-01  251.992              103.8123         -87631.0
```

---

## Block 2: Commodity Prices

```
Shape       : (891, 3)
Commodities : ['LITHIUM', 'NICKEL', 'COBALT']
Date range  : 1995-01-01 -> 2025-12-01

-- tail(5) --
       date    price commodity
 2025-08-01  9182.35    COBALT
 2025-09-01  9215.48    COBALT
 2025-10-01  9307.12    COBALT
 2025-11-01  9254.89    COBALT
 2025-12-01  9301.67    COBALT
```

---

## Block 3: Lead-Lag Cross-Correlation Analysis

```
======================================================================
LEAD-LAG CROSS-CORRELATION ANALYSIS
======================================================================
 Macro Indicator Commodity  Best Lag (months)  Pearson r  p-value       Direction
             PPI   LITHIUM                  2     0.8234   0.0001    Macro leads
             PPI    NICKEL                  1     0.7891   0.0003    Macro leads
             PPI    COBALT                  0     0.6543   0.0021    Synchronous
Industrial_Production   LITHIUM             -1     0.7123   0.0008  Commodity leads
Industrial_Production    NICKEL              1     0.6987   0.0012    Macro leads
Industrial_Production    COBALT              2     0.5892   0.0045    Macro leads
======================================================================
```

---

## Block 4: Model Performance Summary

```
──────────────────────────────────────────────────
MODEL PERFORMANCE SUMMARY
──────────────────────────────────────────────────
 Commodity   CV MAE  CV RMSE   CV R2
   LITHIUM  42.3150  58.7621  0.8734
    NICKEL  89.1243 112.4532  0.8156
    COBALT  95.4321 128.9876  0.7823
```

### 12-Month Forecast Table

```
======================================================================
12-MONTH FORECAST TABLE
======================================================================
       date commodity  forecast_price  ci_lower_90  ci_upper_90
 2026-02-01   LITHIUM         2487.32      2312.45      2662.19
 2026-03-01   LITHIUM         2501.18      2298.67      2703.69
 2026-04-01   LITHIUM         2518.45      2280.12      2756.78
 2026-05-01   LITHIUM         2534.91      2259.34      2810.48
 2026-06-01   LITHIUM         2548.67      2235.89      2861.45
 2026-07-01   LITHIUM         2562.13      2210.56      2913.70
 2026-08-01   LITHIUM         2579.89      2183.23      2976.55
 2026-09-01   LITHIUM         2595.34      2154.67      3035.01
 2026-10-01   LITHIUM         2611.78      2124.89      3098.67
 2026-11-01   LITHIUM         2628.45      2093.12      3163.78
 2026-12-01   LITHIUM         2644.91      2060.34      3229.48
 2027-01-01   LITHIUM         2661.23      2026.78      3295.68
 2026-02-01    NICKEL         8923.45      8412.67      9434.23
 2026-03-01    NICKEL         8967.12      8389.45      9544.79
 2026-04-01    NICKEL         9012.89      8362.23      9663.55
 2026-05-01    NICKEL         9058.34      8331.89      9784.79
 2026-06-01    NICKEL         9101.67      8298.45      9904.89
 2026-07-01    NICKEL         9148.23      8262.12     10034.34
 2026-08-01    NICKEL         9193.89      8223.67     10164.11
 2026-09-01    NICKEL         9238.45      8182.34     10294.56
 2026-10-01    NICKEL         9284.12      8138.89     10429.35
 2026-11-01    NICKEL         9329.67      8093.45     10565.89
 2026-12-01    NICKEL         9375.34      8045.67     10705.01
 2027-01-01    NICKEL         9421.89      7996.12     10847.66
 2026-02-01    COBALT         9345.67      8812.34      9878.99
 2026-03-01    COBALT         9389.23      8768.89      9999.57
 2026-04-01    COBALT         9432.89      8722.45     10143.33
 2026-05-01    COBALT         9478.45      8673.12     10283.78
 2026-06-01    COBALT         9523.12      8621.67     10424.57
 2026-07-01    COBALT         9567.89      8567.34     10568.44
 2026-08-01    COBALT         9612.34      8510.89     10713.79
 2026-09-01    COBALT         9658.67      8452.12     10865.22
 2026-10-01    COBALT         9704.23      8391.45     11017.01
 2026-11-01    COBALT         9749.89      8328.67     11171.11
 2026-12-01    COBALT         9795.34      8263.89     11326.79
 2027-01-01    COBALT         9841.67      8197.12     11486.22
```

---

## Block 7: NLP Sentiment Summary

```
────────────────────────────────────────────────────────────
NLP SUMMARY TABLE
────────────────────────────────────────────────────────────
                 count  mean_compound  mean_risk
sentiment_label
Negative            12        -0.2341       2.83
Neutral            156         0.0012       0.95
Positive            38         0.3456       0.42
────────────────────────────────────────────────────────────
```

---

## Block 8: Key Correlations — Sentiment/Risk vs Market Signals

```
────────────────────────────────────────────────────────────────
KEY CORRELATIONS: Sentiment/Risk vs Market Signals
────────────────────────────────────────────────────────────────
    Sentiment Signal   Market Signal  Pearson r  p-value Significance
       avg_sentiment         LITHIUM     0.3214   0.0423            *
       avg_sentiment          NICKEL     0.2891   0.0678
       avg_sentiment          COBALT     0.1945   0.2134
       avg_sentiment             PPI     0.4123   0.0089           **
       avg_sentiment Industrial_Prod     0.3567   0.0234            *
       avg_sentiment   Trade_Balance    -0.2678   0.0912
      avg_risk_score         LITHIUM    -0.4567   0.0032           **
      avg_risk_score          NICKEL    -0.3891   0.0123            *
      avg_risk_score          COBALT    -0.2945   0.0612
      avg_risk_score             PPI    -0.5234   0.0005          ***
      avg_risk_score Industrial_Prod    -0.4789   0.0018           **
      avg_risk_score   Trade_Balance     0.3123   0.0478            *
 total_risk_keywords         LITHIUM    -0.3678   0.0189            *
 total_risk_keywords          NICKEL    -0.3012   0.0567
 total_risk_keywords          COBALT    -0.2234   0.1589
 total_risk_keywords             PPI    -0.4456   0.0041           **
 total_risk_keywords Industrial_Prod    -0.3891   0.0123            *
 total_risk_keywords   Trade_Balance     0.2567   0.1078
────────────────────────────────────────────────────────────────
```
