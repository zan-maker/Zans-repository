"""
Block 9: Supply Chain Linguistic Analysis
==========================================
Performs term frequency analysis on SEC EDGAR filing text,
produces stacked area charts of key term evolution, a regulatory
heatmap by quarter, and language drift analysis over time.

Zerve DAG position: Depends on edgar_df and all_records (Block 5).
Output: term frequency tables, 3 charts (stacked area, heatmap, drift)
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import re
from collections import Counter

# ─────────────────────────────────────────────────────────────────────────────
# Zerve palette
# ─────────────────────────────────────────────────────────────────────────────
ZERVE_COLORS = {
    "primary":   "#2E86AB",
    "secondary": "#A23B72",
    "accent":    "#F18F01",
    "success":   "#2BA84A",
    "danger":    "#D7263D",
    "dark":      "#1B1B2F",
}

# ─────────────────────────────────────────────────────────────────────────────
# Supply-chain term categories for frequency tracking
# ─────────────────────────────────────────────────────────────────────────────
TERM_CATEGORIES = {
    "Supply Risk": [
        "shortage", "disruption", "supply chain", "bottleneck", "constraint",
        "force majeure", "curtailment", "halt", "suspend",
    ],
    "Regulatory": [
        "tariff", "sanction", "embargo", "quota", "regulation",
        "compliance", "epa", "ira", "inflation reduction act", "chips act",
        "export control", "critical mineral",
    ],
    "Geopolitical": [
        "china", "congo", "drc", "indonesia", "australia", "chile",
        "geopolitical", "trade war", "decoupling", "reshoring", "nearshoring",
    ],
    "ESG & Sustainability": [
        "esg", "sustainability", "carbon", "emissions", "recycling",
        "circular economy", "responsible sourcing", "due diligence",
    ],
    "Technology & Demand": [
        "ev", "electric vehicle", "battery", "cathode", "anode",
        "energy storage", "renewable", "gigafactory",
    ],
}

def count_terms(text: str, terms: list) -> int:
    """Count occurrences of a list of terms in text (case-insensitive)."""
    text_lower = str(text).lower()
    return sum(text_lower.count(term) for term in terms)


# ─────────────────────────────────────────────────────────────────────────────
# Build term frequency DataFrame
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("SUPPLY CHAIN LINGUISTIC ANALYSIS")
print("=" * 70)

# Use text_blob if available, else combine title + company
if "text_blob" not in edgar_df.columns:
    edgar_df["text_blob"] = edgar_df["title"].fillna("") + " " + edgar_df["company"].fillna("")

# Count terms per category per filing
for category, terms in TERM_CATEGORIES.items():
    col = f"tf_{category}"
    edgar_df[col] = edgar_df["text_blob"].apply(lambda t: count_terms(t, terms))

tf_cols = [f"tf_{cat}" for cat in TERM_CATEGORIES.keys()]

# ── Quarterly aggregation ────────────────────────────────────────────────────
edgar_df["quarter"] = edgar_df["date"].dt.to_period("Q")

quarterly_tf = (
    edgar_df
    .groupby("quarter")[tf_cols]
    .sum()
    .rename(columns=lambda c: c.replace("tf_", ""))
)

print(f"\nQuarterly term frequency matrix: {quarterly_tf.shape}")
print(quarterly_tf.tail(8).to_string())

# ─────────────────────────────────────────────────────────────────────────────
# Chart 1: Stacked Area — Term Category Evolution
# ─────────────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(14, 6))
quarterly_tf_plot = quarterly_tf.copy()
quarterly_tf_plot.index = quarterly_tf_plot.index.to_timestamp()

colors = [ZERVE_COLORS["primary"], ZERVE_COLORS["danger"], ZERVE_COLORS["accent"],
          ZERVE_COLORS["success"], ZERVE_COLORS["secondary"]]

ax.stackplot(quarterly_tf_plot.index, quarterly_tf_plot.values.T,
             labels=quarterly_tf_plot.columns, colors=colors, alpha=0.75)
ax.set_title("Supply Chain Language Evolution — Term Frequency by Category",
             fontsize=14, fontweight="bold")
ax.set_xlabel("Quarter")
ax.set_ylabel("Total Term Mentions")
ax.legend(loc="upper left", fontsize=9, framealpha=0.9)
fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Chart 2: Regulatory Heatmap by Quarter
# ─────────────────────────────────────────────────────────────────────────────
reg_terms = TERM_CATEGORIES["Regulatory"]

# Count each regulatory term per quarter
reg_matrix = pd.DataFrame(index=edgar_df["quarter"].unique())
for term in reg_terms:
    reg_matrix[term] = edgar_df.groupby("quarter").apply(
        lambda g: g["text_blob"].str.lower().str.count(term).sum()
    )
reg_matrix = reg_matrix.sort_index().fillna(0)

fig, ax = plt.subplots(figsize=(14, 6))
im = ax.imshow(reg_matrix.T.values, cmap="YlOrRd", aspect="auto")
ax.set_xticks(range(len(reg_matrix)))
ax.set_xticklabels([str(q) for q in reg_matrix.index], rotation=45, ha="right", fontsize=8)
ax.set_yticks(range(len(reg_terms)))
ax.set_yticklabels(reg_terms, fontsize=9)

for i in range(len(reg_terms)):
    for j in range(len(reg_matrix)):
        val = int(reg_matrix.iloc[j, i])
        if val > 0:
            ax.text(j, i, str(val), ha="center", va="center", fontsize=7,
                    color="white" if val > reg_matrix.values.max() * 0.5 else "black")

plt.colorbar(im, ax=ax, shrink=0.8, label="Mentions")
ax.set_title("Regulatory Term Heatmap by Quarter", fontsize=14, fontweight="bold")
fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Chart 3: Language Drift — Cosine Similarity Between Quarters
# ─────────────────────────────────────────────────────────────────────────────
from numpy.linalg import norm

def cosine_sim(a, b):
    """Cosine similarity between two vectors."""
    if norm(a) == 0 or norm(b) == 0:
        return 0.0
    return np.dot(a, b) / (norm(a) * norm(b))

# Compute quarter-over-quarter cosine similarity of term frequency vectors
quarters = quarterly_tf.index.tolist()
drift_records = []
for i in range(1, len(quarters)):
    vec_prev = quarterly_tf.iloc[i - 1].values.astype(float)
    vec_curr = quarterly_tf.iloc[i].values.astype(float)
    sim = cosine_sim(vec_prev, vec_curr)
    drift_records.append({
        "quarter": quarters[i],
        "cosine_similarity": round(sim, 4),
        "drift": round(1 - sim, 4),
    })

drift_df = pd.DataFrame(drift_records)
drift_df["quarter_ts"] = drift_df["quarter"].apply(lambda q: q.to_timestamp())

fig, ax = plt.subplots(figsize=(12, 5))
ax.bar(drift_df["quarter_ts"], drift_df["drift"], width=60,
       color=ZERVE_COLORS["accent"], alpha=0.8, edgecolor="white")
ax.plot(drift_df["quarter_ts"], drift_df["drift"],
        color=ZERVE_COLORS["dark"], linewidth=1.5, marker="o", markersize=5)
ax.set_title("Language Drift — Quarter-over-Quarter (1 - Cosine Similarity)",
             fontsize=13, fontweight="bold")
ax.set_xlabel("Quarter")
ax.set_ylabel("Drift (1 - cos sim)")
ax.set_ylim(0, 1)
fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "─" * 60)
print("LINGUISTIC ANALYSIS SUMMARY")
print("─" * 60)
total_by_cat = quarterly_tf.sum().sort_values(ascending=False)
for cat, total in total_by_cat.items():
    print(f"  {cat:30s} : {int(total):6d} mentions")
print(f"\n  Avg quarter-over-quarter drift : {drift_df['drift'].mean():.4f}")
print("─" * 60)
