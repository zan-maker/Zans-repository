"""
Block 1: Fetch FRED Macroeconomic Data
=======================================
Ingests PPI, Industrial Production, and Trade Balance from the
Federal Reserve Bank of St. Louis (FRED) REST API.

Zerve DAG position: Independent ingestion block (no upstream dependencies).
Output variable: fred_df (DatetimeIndex, 3 columns)
"""
import requests
import pandas as pd
import os

# ─────────────────────────────────────────────────────────────────────────────
# FRED API Configuration
# ─────────────────────────────────────────────────────────────────────────────
FRED_BASE_URL = "https://api.stlouisfed.org/fred/series/observations"
FRED_API_KEY = os.environ.get("FRED_API_KEY", "your-fred-api-key-here")

# Validate key is set before making requests
if not FRED_API_KEY or FRED_API_KEY == "your-fred-api-key-here":
    raise EnvironmentError(
        "FRED API key is not configured.\n"
        "  1. Get a free key at: https://fred.stlouisfed.org/docs/api/api_key.html\n"
        "  2. Then either:\n"
        "     a) Set the FRED_API_KEY environment variable in your canvas settings, OR\n"
        "     b) Replace 'your-fred-api-key-here' in this block with your actual key."
    )

# FRED series to fetch (2020-01-01 onward)
SERIES = {
    "PPI": "PPIACO",                    # Producer Price Index: All Commodities
    "Industrial_Production": "INDPRO",  # Industrial Production Index
    "Trade_Balance": "BOPGSTB",         # Trade Balance: Goods & Services (BOP)
}
START_DATE = "2020-01-01"

def fetch_fred_series(series_id: str, api_key: str, start_date: str) -> pd.Series:
    """Fetch a single FRED series and return as a pd.Series indexed by date."""
    params = {
        "series_id": series_id,
        "api_key": api_key,
        "file_type": "json",
        "observation_start": start_date,
        "sort_order": "asc",
    }

    response = requests.get(FRED_BASE_URL, params=params, timeout=15)

    # Surface FRED's JSON error message before raising HTTP error
    if not response.ok:
        json_body = {}
        try:
            json_body = response.json()
        except Exception:
            pass
        fred_msg = json_body.get("error_message", "")
        raise RuntimeError(
            f"FRED API HTTP {response.status_code} for series '{series_id}'. "
            f"FRED message: '{fred_msg}'. "
            f"URL: {response.url}"
        )

    data = response.json()

    # FRED returns error details in JSON body even on 200 sometimes
    if "error_code" in data:
        raise RuntimeError(
            f"FRED API error for series '{series_id}': "
            f"{data.get('error_message', 'Unknown error')}"
        )

    observations = data.get("observations", [])
    if not observations:
        raise ValueError(f"No observations returned for series '{series_id}'")

    # Filter out missing values (FRED uses "." as placeholder)
    records = [
        (obs["date"], float(obs["value"]))
        for obs in observations
        if obs["value"] != "."
    ]

    if not records:
        raise ValueError(f"All observations are missing for series '{series_id}'")

    dates, values = zip(*records)
    return pd.Series(values, index=pd.to_datetime(dates), name=series_id)

# ─────────────────────────────────────────────────────────────────────────────
# Fetch all series
# ─────────────────────────────────────────────────────────────────────────────
series_frames = {}
for col_name, series_id in SERIES.items():
    print(f"Fetching {col_name} ({series_id})...")
    series_frames[col_name] = fetch_fred_series(series_id, FRED_API_KEY, START_DATE)
    print(f"  ✓ {len(series_frames[col_name])} observations")

# ─────────────────────────────────────────────────────────────────────────────
# Combine into a single date-aligned DataFrame
# ─────────────────────────────────────────────────────────────────────────────
fred_df = pd.DataFrame(series_frames)
fred_df.index.name = "Date"
fred_df.sort_index(inplace=True)
fred_df.dropna(how="all", inplace=True)  # Remove rows with all NaN (alignment artifacts)

# ─────────────────────────────────────────────────────────────────────────────
# Summary output
# ─────────────────────────────────────────────────────────────────────────────
print(f"\n{'─'*52}")
print(f"✅ fred_df populated successfully")
print(f"   Shape      : {fred_df.shape}  (rows × columns)")
print(f"   Date range : {fred_df.index.min().date()} → {fred_df.index.max().date()}")
print(f"   Columns    : {list(fred_df.columns)}")
print(f"   NaN count  : {fred_df.isna().sum().to_dict()}")
print(f"{'─'*52}")
print(f"\n--- tail(5) preview ---")
print(fred_df.tail(5).to_string())
