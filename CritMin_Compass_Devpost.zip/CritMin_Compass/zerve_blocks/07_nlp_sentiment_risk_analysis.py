"""
Block 7: NLP Sentiment & Risk Keyword Analysis
================================================
Applies VADER sentiment analysis and custom risk-keyword scoring
to SEC EDGAR filing titles/descriptions. Produces 3 charts:
sentiment distribution, risk score timeline, and risk vs sentiment scatter.

Zerve DAG position: Depends on edgar_df and all_records (Block 5).
Output variables: nlp_analysis_df
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# ─────────────────────────────────────────────────────────────────────────────
# Ensure VADER lexicon is available
# ─────────────────────────────────────────────────────────────────────────────
nltk.download("vader_lexicon", quiet=True)
sia = SentimentIntensityAnalyzer()

# ─────────────────────────────────────────────────────────────────────────────
# Zerve design palette
# ─────────────────────────────────────────────────────────────────────────────
ZERVE_COLORS = {
    "primary":   "#2E86AB",
    "secondary": "#A23B72",
    "accent":    "#F18F01",
    "success":   "#2BA84A",
    "danger":    "#D7263D",
    "dark":      "#1B1B2F",
}

# ─────────────────────────────────────────────────────────────────────────────
# Risk keyword lexicon for supply-chain / critical-mineral context
# ─────────────────────────────────────────────────────────────────────────────
RISK_KEYWORDS = {
    "high": [
        "shortage", "disruption", "embargo", "sanction", "ban",
        "force majeure", "curtailment", "halt", "suspend", "crisis",
    ],
    "medium": [
        "tariff", "quota", "delay", "constraint", "volatility",
        "uncertainty", "bottleneck", "inventory drawdown", "tight supply",
    ],
    "low": [
        "risk", "concern", "challenge", "fluctuation", "dependency",
        "exposure", "sensitivity", "vulnerability",
    ],
}

RISK_WEIGHTS = {"high": 3, "medium": 2, "low": 1}


def compute_risk_score(text: str) -> dict:
    """Score a text string against the supply-chain risk lexicon."""
    text_lower = str(text).lower()
    total_score = 0
    matched = []

    for level, keywords in RISK_KEYWORDS.items():
        for kw in keywords:
            count = text_lower.count(kw)
            if count > 0:
                total_score += count * RISK_WEIGHTS[level]
                matched.append(f"{kw}({level})")

    return {
        "risk_score": total_score,
        "risk_keywords_matched": ", ".join(matched) if matched else "none",
        "risk_keyword_count": len(matched),
    }


def compute_sentiment(text: str) -> dict:
    """VADER sentiment scores for a text string."""
    scores = sia.polarity_scores(str(text))
    return {
        "sentiment_neg":      scores["neg"],
        "sentiment_neu":      scores["neu"],
        "sentiment_pos":      scores["pos"],
        "sentiment_compound": scores["compound"],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Apply NLP to edgar_df
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("NLP SENTIMENT & RISK ANALYSIS")
print("=" * 70)

# Combine title + company for richer text signal
edgar_df["text_blob"] = edgar_df["title"].fillna("") + " " + edgar_df["company"].fillna("")

# Sentiment scores
sentiment_records = edgar_df["text_blob"].apply(compute_sentiment).apply(pd.Series)
risk_records      = edgar_df["text_blob"].apply(compute_risk_score).apply(pd.Series)

nlp_analysis_df = pd.concat([edgar_df, sentiment_records, risk_records], axis=1)

# Classify sentiment
nlp_analysis_df["sentiment_label"] = pd.cut(
    nlp_analysis_df["sentiment_compound"],
    bins=[-1.01, -0.05, 0.05, 1.01],
    labels=["Negative", "Neutral", "Positive"],
)

print(f"\n✅ NLP analysis complete: {nlp_analysis_df.shape[0]} records scored")
print(f"   Sentiment distribution:")
print(f"   {nlp_analysis_df['sentiment_label'].value_counts().to_dict()}")
print(f"   Mean compound sentiment: {nlp_analysis_df['sentiment_compound'].mean():.4f}")
print(f"   Mean risk score: {nlp_analysis_df['risk_score'].mean():.2f}")

# ─────────────────────────────────────────────────────────────────────────────
# Chart 1: Sentiment Distribution (histogram)
# ─────────────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(10, 5))
ax.hist(nlp_analysis_df["sentiment_compound"], bins=30, color=ZERVE_COLORS["primary"],
        edgecolor="white", alpha=0.85)
ax.axvline(0, color=ZERVE_COLORS["danger"], linestyle="--", linewidth=1.5, label="Neutral threshold")
ax.set_title("Distribution of VADER Compound Sentiment Scores", fontsize=13, fontweight="bold")
ax.set_xlabel("Compound Sentiment Score")
ax.set_ylabel("Frequency")
ax.legend()
fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Chart 2: Risk Score Timeline
# ─────────────────────────────────────────────────────────────────────────────
if "date" in nlp_analysis_df.columns and nlp_analysis_df["date"].notna().any():
    monthly_risk = (
        nlp_analysis_df
        .set_index("date")
        .resample("MS")["risk_score"]
        .mean()
        .dropna()
    )

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.fill_between(monthly_risk.index, monthly_risk.values,
                    color=ZERVE_COLORS["danger"], alpha=0.3)
    ax.plot(monthly_risk.index, monthly_risk.values,
            color=ZERVE_COLORS["danger"], linewidth=2)
    ax.set_title("Monthly Average Risk Score — Supply Chain Filings",
                 fontsize=13, fontweight="bold")
    ax.set_xlabel("Date")
    ax.set_ylabel("Avg Risk Score")
    fig.tight_layout()
    plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Chart 3: Risk Score vs Sentiment (scatter)
# ─────────────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 6))
scatter = ax.scatter(
    nlp_analysis_df["sentiment_compound"],
    nlp_analysis_df["risk_score"],
    c=nlp_analysis_df["risk_score"],
    cmap="YlOrRd",
    alpha=0.7,
    edgecolors="white",
    linewidths=0.5,
    s=60,
)
plt.colorbar(scatter, ax=ax, label="Risk Score")
ax.set_title("Risk Score vs Sentiment Compound", fontsize=13, fontweight="bold")
ax.set_xlabel("VADER Compound Sentiment")
ax.set_ylabel("Risk Score")
fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Summary table
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "─" * 60)
print("NLP SUMMARY TABLE")
print("─" * 60)
summary = nlp_analysis_df.groupby("sentiment_label").agg(
    count=("sentiment_compound", "count"),
    mean_compound=("sentiment_compound", "mean"),
    mean_risk=("risk_score", "mean"),
).round(4)
print(summary.to_string())
print("─" * 60)
