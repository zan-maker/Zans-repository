"""
Block 5: SEC EDGAR Supply Chain Filing Ingestion
==================================================
Fetches 10-K and 10-Q filing metadata from the SEC EDGAR
full-text search API for critical-mineral-related queries.
Falls back to API Ninjas commodity price endpoint when EDGAR
returns no results for a given search term.

Zerve DAG position: Independent ingestion block (no upstream dependencies).
Output variables: edgar_df, all_records
"""
import requests
import pandas as pd
import time
import os

# ─────────────────────────────────────────────────────────────────────────────
# SEC EDGAR Full-Text Search API
# ─────────────────────────────────────────────────────────────────────────────
EDGAR_SEARCH_URL = "https://efts.sec.gov/LATEST/search-index"
EDGAR_FILING_URL = "https://efts.sec.gov/LATEST/search-index"

# SEC requires a User-Agent header with contact info
HEADERS = {
    "User-Agent": "CritMinCompass/1.0 (critmin-compass@example.com)",
    "Accept": "application/json",
}

# ─────────────────────────────────────────────────────────────────────────────
# API Ninjas fallback (commodity prices when EDGAR has no results)
# ─────────────────────────────────────────────────────────────────────────────
API_NINJAS_KEY = os.environ.get("API_NINJAS_KEY", "your-api-ninjas-key-here")
API_NINJAS_URL = "https://api.api-ninjas.com/v1/commodityprice"

# ─────────────────────────────────────────────────────────────────────────────
# Search terms for critical mineral supply chain filings
# ─────────────────────────────────────────────────────────────────────────────
SEARCH_TERMS = [
    "lithium supply chain",
    "cobalt sourcing",
    "nickel mining",
    "critical mineral",
    "battery supply chain",
    "rare earth supply",
]

FORM_TYPES = ["10-K", "10-Q"]
DATE_RANGE_START = "2020-01-01"
DATE_RANGE_END   = "2026-01-01"

def search_edgar(query: str, form_types: list, start: str, end: str,
                 max_results: int = 50) -> list:
    """
    Search SEC EDGAR full-text search for filings matching a query.

    Returns list of dicts with keys: company, cik, form_type, date, title, url.
    """
    params = {
        "q":          query,
        "dateRange":  "custom",
        "startdt":    start,
        "enddt":      end,
        "forms":      ",".join(form_types),
    }

    try:
        resp = requests.get(
            "https://efts.sec.gov/LATEST/search-index",
            params=params,
            headers=HEADERS,
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.RequestException as e:
        print(f"    ⚠ EDGAR request failed for '{query}': {e}")
        return []

    hits = data.get("hits", {}).get("hits", [])
    records = []
    for hit in hits[:max_results]:
        src = hit.get("_source", {})
        records.append({
            "company":   src.get("entity_name", "Unknown"),
            "cik":       src.get("entity_id", ""),
            "form_type": src.get("form_type", ""),
            "date":      src.get("file_date", ""),
            "title":     src.get("file_description", ""),
            "url":       f"https://www.sec.gov/Archives/edgar/data/{src.get('entity_id', '')}/{src.get('file_num', '')}",
            "source":    "EDGAR",
            "query":     query,
        })
    return records


def fetch_api_ninjas_commodity(commodity_name: str) -> list:
    """Fallback: fetch commodity price from API Ninjas."""
    headers = {"X-Api-Key": API_NINJAS_KEY}
    params  = {"name": commodity_name}

    try:
        resp = requests.get(API_NINJAS_URL, headers=headers, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.RequestException as e:
        print(f"    ⚠ API Ninjas request failed for '{commodity_name}': {e}")
        return []

    records = []
    if isinstance(data, dict) and "name" in data:
        records.append({
            "company":   data.get("name", commodity_name),
            "cik":       "",
            "form_type": "COMMODITY_PRICE",
            "date":      pd.Timestamp.now().strftime("%Y-%m-%d"),
            "title":     f"Spot price: {data.get('price', 'N/A')} {data.get('currency', 'USD')}",
            "url":       "",
            "source":    "API_Ninjas",
            "query":     commodity_name,
        })
    return records


# ─────────────────────────────────────────────────────────────────────────────
# Run EDGAR searches with API Ninjas fallback
# ─────────────────────────────────────────────────────────────────────────────
all_records = []

print("=" * 70)
print("SEC EDGAR SUPPLY CHAIN FILING SEARCH")
print("=" * 70)

for term in SEARCH_TERMS:
    print(f"\n🔍 Searching: '{term}'")
    records = search_edgar(term, FORM_TYPES, DATE_RANGE_START, DATE_RANGE_END)

    if records:
        print(f"   ✓ {len(records)} filings found")
        all_records.extend(records)
    else:
        print(f"   ⚠ No EDGAR results — falling back to API Ninjas …")
        commodity_name = term.split()[0]  # first word as commodity lookup
        fallback = fetch_api_ninjas_commodity(commodity_name)
        if fallback:
            print(f"   ✓ API Ninjas returned {len(fallback)} record(s)")
            all_records.extend(fallback)
        else:
            print(f"   ✗ No data from either source for '{term}'")

    time.sleep(0.5)  # respect SEC rate limits

# ─────────────────────────────────────────────────────────────────────────────
# Build edgar_df
# ─────────────────────────────────────────────────────────────────────────────
edgar_df = pd.DataFrame(all_records)

if not edgar_df.empty:
    edgar_df["date"] = pd.to_datetime(edgar_df["date"], errors="coerce")
    edgar_df.sort_values("date", inplace=True)
    edgar_df.reset_index(drop=True, inplace=True)

print(f"\n{'─'*52}")
print(f"✅ edgar_df populated: {edgar_df.shape[0]} rows × {edgar_df.shape[1]} cols")
if not edgar_df.empty:
    print(f"   Date range : {edgar_df['date'].min()} → {edgar_df['date'].max()}")
    print(f"   Sources    : {edgar_df['source'].value_counts().to_dict()}")
    print(f"   Columns    : {list(edgar_df.columns)}")
print(f"{'─'*52}")

print("\n── tail(5) ──────────────────────────────────────────")
print(edgar_df.tail(5).to_string())
