"""
Block 2: Fetch Commodity Spot Prices
=====================================
Ingests monthly commodity price data from Alpha Vantage API.
Uses proxy commodities (Aluminum->Lithium, Copper->Nickel, All Commodities->Cobalt)
since Alpha Vantage does not provide direct Li/Ni/Co endpoints.

Zerve DAG position: Independent ingestion block (no upstream dependencies).
Output variable: commodities_df (columns: date, price, commodity)
"""
import requests
import pandas as pd
import time
import os

# ─────────────────────────────────────────────────────────────────────────────
# Alpha Vantage Physical & Industrial Commodities API
# ─────────────────────────────────────────────────────────────────────────────
API_KEY = os.environ.get("ALPHA_VANTAGE_API_KEY", "your-alpha-vantage-key-here")

BASE_URL = "https://www.alphavantage.co/query"

COMMODITIES = {
    "LITHIUM": "ALUMINUM",          # Proxy: lightweight base metal
    "NICKEL":  "COPPER",            # Proxy: industrial base metal
    "COBALT":  "ALL_COMMODITIES",   # Proxy: commodity index for critical minerals
}

RATE_LIMIT_SLEEP = 20  # seconds between requests (free tier: 5 req/min)

def fetch_commodity(commodity_label: str, av_function: str, api_key: str) -> pd.DataFrame:
    """
    Fetch monthly commodity spot price series from Alpha Vantage.

    Parameters
    ----------
    commodity_label : user-facing name (e.g. LITHIUM / NICKEL / COBALT)
    av_function     : actual Alpha Vantage function name
    api_key         : Alpha Vantage API key

    Returns
    -------
    pd.DataFrame with columns: date (datetime), price (float), commodity (str)
    """
    params = {
        "function": av_function,
        "interval": "monthly",
        "apikey":   api_key,
    }
    response = requests.get(BASE_URL, params=params, timeout=15)
    response.raise_for_status()
    payload = response.json()

    # Rate-limit / auth errors come back as {"Information": "..."} or {"Note": "..."}
    if "Information" in payload or "Note" in payload:
        msg = payload.get("Information") or payload.get("Note")
        raise RuntimeError(
            f"Alpha Vantage rate-limit or auth error for {commodity_label}: {msg}"
        )

    if "data" not in payload:
        raise ValueError(
            f"Unexpected API response for {commodity_label} (function={av_function}). "
            f"Keys returned: {list(payload.keys())}. Response: {str(payload)[:300]}"
        )

    df = pd.DataFrame(payload["data"])
    df["date"]      = pd.to_datetime(df["date"])
    df["price"]     = pd.to_numeric(df["value"], errors="coerce")
    df["commodity"] = commodity_label
    df = (
        df[["date", "price", "commodity"]]
        .dropna(subset=["price"])
        .sort_values("date")
        .reset_index(drop=True)
    )
    return df

# ─────────────────────────────────────────────────────────────────────────────
# Fetch all three commodities with rate-limit spacing
# ─────────────────────────────────────────────────────────────────────────────
frames = []
for _comm_idx, (label, av_fn) in enumerate(COMMODITIES.items()):
    if _comm_idx > 0:
        print(f"  ⏳ Sleeping {RATE_LIMIT_SLEEP}s to respect free-tier rate limit …")
        time.sleep(RATE_LIMIT_SLEEP)

    print(f"  Fetching {label} (AV function: {av_fn}) …")
    df_c = fetch_commodity(label, av_fn, API_KEY)
    frames.append(df_c)
    print(f"    ✓ {len(df_c)} monthly data points  "
          f"({df_c['date'].min().date()} → {df_c['date'].max().date()})")

commodities_df = pd.concat(frames, ignore_index=True)

# ─────────────────────────────────────────────────────────────────────────────
# Summary output
# ─────────────────────────────────────────────────────────────────────────────
print("\n━━━ commodities_df ━━━")
print(f"Shape       : {commodities_df.shape}")
print(f"Commodities : {commodities_df['commodity'].unique().tolist()}")
print(f"Date range  : {commodities_df['date'].min().date()} → {commodities_df['date'].max().date()}")

print("\n── tail(5) ──────────────────────────────────────────────────────")
print(commodities_df.tail(5).to_string(index=False))
