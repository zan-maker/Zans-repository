"""
Block 8: Correlation Analysis — Sentiment vs Market Signals
=============================================================
Computes Pearson correlations between NLP sentiment/risk scores
and commodity prices / FRED macro indicators. Produces a heatmap
and multi-axis overlay chart.

Zerve DAG position: Depends on nlp_analysis_df (Block 7),
                    commodities_df (Block 2), fred_df (Block 1).
Output: correlation matrix, heatmap chart, overlay chart
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# ─────────────────────────────────────────────────────────────────────────────
# Zerve palette
# ─────────────────────────────────────────────────────────────────────────────
ZERVE_COLORS = {
    "primary":   "#2E86AB",
    "secondary": "#A23B72",
    "accent":    "#F18F01",
    "success":   "#2BA84A",
    "danger":    "#D7263D",
    "dark":      "#1B1B2F",
}

# ─────────────────────────────────────────────────────────────────────────────
# Build monthly aggregated sentiment signals
# ─────────────────────────────────────────────────────────────────────────────
sentiment_monthly = (
    nlp_analysis_df
    .dropna(subset=["date"])
    .set_index("date")
    .resample("MS")
    .agg({
        "sentiment_compound": "mean",
        "risk_score":         "mean",
        "risk_keyword_count": "sum",
    })
    .rename(columns={
        "sentiment_compound": "avg_sentiment",
        "risk_score":         "avg_risk_score",
        "risk_keyword_count": "total_risk_keywords",
    })
)

# ─────────────────────────────────────────────────────────────────────────────
# Pivot commodity prices to monthly wide format
# ─────────────────────────────────────────────────────────────────────────────
comm_wide = commodities_df.copy()
comm_wide["month"] = comm_wide["date"].dt.to_period("M").dt.to_timestamp()
comm_wide = comm_wide.pivot_table(index="month", columns="commodity", values="price", aggfunc="mean")

# FRED monthly
fred_monthly = fred_df.resample("MS").mean()

# ─────────────────────────────────────────────────────────────────────────────
# Merge all signals on common dates
# ─────────────────────────────────────────────────────────────────────────────
merged = (
    sentiment_monthly
    .join(comm_wide, how="inner")
    .join(fred_monthly, how="inner")
    .dropna()
)

print(f"Merged signal matrix: {merged.shape[0]} months × {merged.shape[1]} columns")
print(f"Columns: {list(merged.columns)}")

# ─────────────────────────────────────────────────────────────────────────────
# Pearson correlation matrix
# ─────────────────────────────────────────────────────────────────────────────
corr_matrix = merged.corr(method="pearson")

print("\n" + "=" * 70)
print("PEARSON CORRELATION MATRIX")
print("=" * 70)
print(corr_matrix.round(3).to_string())

# ─────────────────────────────────────────────────────────────────────────────
# Significance testing (p-values)
# ─────────────────────────────────────────────────────────────────────────────
n_cols = len(merged.columns)
p_matrix = pd.DataFrame(np.zeros((n_cols, n_cols)),
                        index=merged.columns, columns=merged.columns)

for i, col_a in enumerate(merged.columns):
    for j, col_b in enumerate(merged.columns):
        if i == j:
            p_matrix.iloc[i, j] = 0.0
        else:
            _, p_val = stats.pearsonr(merged[col_a], merged[col_b])
            p_matrix.iloc[i, j] = p_val

print("\n" + "─" * 50)
print("P-VALUE MATRIX (significance)")
print("─" * 50)
print(p_matrix.round(4).to_string())

# ─────────────────────────────────────────────────────────────────────────────
# Key correlation pairs (sentiment/risk vs market signals)
# ─────────────────────────────────────────────────────────────────────────────
sentiment_cols = ["avg_sentiment", "avg_risk_score", "total_risk_keywords"]
market_cols    = [c for c in merged.columns if c not in sentiment_cols]

print("\n" + "─" * 60)
print("KEY CORRELATIONS: Sentiment/Risk vs Market Signals")
print("─" * 60)

key_corrs = []
for s_col in sentiment_cols:
    for m_col in market_cols:
        r = corr_matrix.loc[s_col, m_col]
        p = p_matrix.loc[s_col, m_col]
        sig = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else ""
        key_corrs.append({
            "Sentiment Signal": s_col,
            "Market Signal": m_col,
            "Pearson r": round(r, 4),
            "p-value": round(p, 4),
            "Significance": sig,
        })

key_corr_df = pd.DataFrame(key_corrs)
print(key_corr_df.to_string(index=False))

# ─────────────────────────────────────────────────────────────────────────────
# Chart 1: Correlation Heatmap
# ─────────────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(12, 9))
im = ax.imshow(corr_matrix.values, cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto")
ax.set_xticks(range(len(corr_matrix.columns)))
ax.set_yticks(range(len(corr_matrix.columns)))
ax.set_xticklabels(corr_matrix.columns, rotation=45, ha="right", fontsize=9)
ax.set_yticklabels(corr_matrix.columns, fontsize=9)

# Annotate cells
for i in range(len(corr_matrix)):
    for j in range(len(corr_matrix)):
        val = corr_matrix.iloc[i, j]
        color = "white" if abs(val) > 0.5 else "black"
        ax.text(j, i, f"{val:.2f}", ha="center", va="center", color=color, fontsize=8)

plt.colorbar(im, ax=ax, shrink=0.8, label="Pearson r")
ax.set_title("Correlation Heatmap — Sentiment, Risk & Market Signals",
             fontsize=14, fontweight="bold", pad=15)
fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Chart 2: Multi-axis Overlay — Sentiment + Risk + Commodity
# ─────────────────────────────────────────────────────────────────────────────
fig, ax1 = plt.subplots(figsize=(14, 6))
ax1.set_title("Sentiment & Risk Score vs Commodity Prices (Monthly)",
              fontsize=13, fontweight="bold")

# Sentiment on left axis
ax1.set_ylabel("Avg Sentiment Compound", color=ZERVE_COLORS["primary"])
ax1.plot(merged.index, merged["avg_sentiment"], color=ZERVE_COLORS["primary"],
         linewidth=2, label="Avg Sentiment")
ax1.tick_params(axis="y", labelcolor=ZERVE_COLORS["primary"])
ax1.axhline(0, color="grey", linewidth=0.5, linestyle="--")

# Risk score on right axis
ax2 = ax1.twinx()
ax2.set_ylabel("Avg Risk Score", color=ZERVE_COLORS["danger"])
ax2.bar(merged.index, merged["avg_risk_score"], width=20, alpha=0.3,
        color=ZERVE_COLORS["danger"], label="Avg Risk Score")
ax2.tick_params(axis="y", labelcolor=ZERVE_COLORS["danger"])

lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left", framealpha=0.9)

fig.tight_layout()
plt.show()
