"""
Block 6: Dataset Summary & Freshness Report
=============================================
Generates a consolidated summary report across all three ingested
datasets: FRED macro data, commodity prices, and SEC EDGAR filings.

Zerve DAG position: Depends on fred_df (Block 1), commodities_df (Block 2),
                    and edgar_df (Block 5).
Output: printed summary tables with row counts, date ranges, freshness.
"""
import pandas as pd

# ─────────────────────────────────────────────────────────────────────────────
# Dataset summary
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("DATASET SUMMARY & FRESHNESS REPORT")
print("=" * 70)

# ── FRED Macro Data ──────────────────────────────────────────────────────────
print("\n📊 1. FRED Macroeconomic Data (fred_df)")
print(f"   Rows      : {fred_df.shape[0]}")
print(f"   Columns   : {list(fred_df.columns)}")
print(f"   Date range: {fred_df.index.min().date()} → {fred_df.index.max().date()}")
print(f"   NaN count : {fred_df.isna().sum().to_dict()}")
print(f"   Freshness : last observation {fred_df.index.max().date()}")

# ── Commodity Prices ─────────────────────────────────────────────────────────
print(f"\n📊 2. Commodity Prices (commodities_df)")
print(f"   Rows      : {commodities_df.shape[0]}")
print(f"   Commodities: {commodities_df['commodity'].unique().tolist()}")
print(f"   Date range: {commodities_df['date'].min().date()} → {commodities_df['date'].max().date()}")
per_commodity = commodities_df.groupby("commodity").agg(
    count=("price", "count"),
    min_date=("date", "min"),
    max_date=("date", "max"),
    mean_price=("price", "mean"),
).round(2)
print(per_commodity.to_string())

# ── SEC EDGAR Filings ────────────────────────────────────────────────────────
print(f"\n📊 3. SEC EDGAR Supply Chain Filings (edgar_df)")
print(f"   Rows      : {edgar_df.shape[0]}")
print(f"   Columns   : {list(edgar_df.columns)}")

# BUG: edgar_df does not contain 'search_term' or 'filing_date' columns — see runtime error
# The actual columns are 'query' and 'date'. These lines will raise KeyError at runtime.
if not edgar_df.empty:
    print(f"   Search terms: {edgar_df['search_term'].nunique()} unique")  # BUG: should be 'query'
    print(f"   Date range  : {edgar_df['filing_date'].min()} → {edgar_df['filing_date'].max()}")  # BUG: should be 'date'
    print(f"   Sources     : {edgar_df['source'].value_counts().to_dict()}")

# ── Freshness matrix ─────────────────────────────────────────────────────────
print("\n" + "─" * 50)
print("DATA FRESHNESS MATRIX")
print("─" * 50)
freshness = pd.DataFrame([
    {
        "Dataset": "FRED Macro",
        "Last Observation": str(fred_df.index.max().date()),
        "Total Rows": fred_df.shape[0],
        "Status": "✅ Fresh" if (pd.Timestamp.now() - fred_df.index.max()).days < 90 else "⚠ Stale",
    },
    {
        "Dataset": "Commodity Prices",
        "Last Observation": str(commodities_df["date"].max().date()),
        "Total Rows": commodities_df.shape[0],
        "Status": "✅ Fresh" if (pd.Timestamp.now() - commodities_df["date"].max()).days < 90 else "⚠ Stale",
    },
    {
        "Dataset": "SEC EDGAR Filings",
        "Last Observation": str(edgar_df["date"].max().date()) if not edgar_df.empty else "N/A",
        "Total Rows": edgar_df.shape[0],
        "Status": "✅ Fresh" if (not edgar_df.empty and (pd.Timestamp.now() - edgar_df["date"].max()).days < 90) else "⚠ Stale",
    },
])
print(freshness.to_string(index=False))
print("─" * 50)
