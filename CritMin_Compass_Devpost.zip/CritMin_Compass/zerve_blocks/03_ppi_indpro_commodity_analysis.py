"""
Block 3: PPI / Industrial Production vs Commodity Price Analysis
=================================================================
Produces dual-axis charts comparing FRED macro indicators against
commodity prices, computes rolling correlations, and performs
lead-lag (cross-correlation) analysis.

Zerve DAG position: Depends on fred_df (Block 1) and commodities_df (Block 2).
Output variables: correlation tables, 4 matplotlib charts
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# ─────────────────────────────────────────────────────────────────────────────
# Zerve Design System Colors
# ─────────────────────────────────────────────────────────────────────────────
ZERVE_COLORS = {
    "primary":   "#2E86AB",  # Steel blue
    "secondary": "#A23B72",  # Berry
    "accent":    "#F18F01",  # Amber
    "success":   "#2BA84A",  # Green
    "dark":      "#1B1B2F",  # Near-black
    "light":     "#E8E8E8",  # Light grey
}

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor":   "#FAFAFA",
    "axes.grid":        True,
    "grid.alpha":       0.3,
    "font.size":        11,
})

# ─────────────────────────────────────────────────────────────────────────────
# Prepare aligned monthly DataFrames
# ─────────────────────────────────────────────────────────────────────────────
# Pivot commodities_df to wide format indexed by month
commodities_wide = commodities_df.copy()
commodities_wide["month"] = commodities_wide["date"].dt.to_period("M").dt.to_timestamp()
commodities_wide = commodities_wide.pivot_table(
    index="month", columns="commodity", values="price", aggfunc="mean"
)

# Resample FRED data to monthly (some series are already monthly)
fred_monthly = fred_df.resample("MS").mean()

# Align on common date range
common_start = max(fred_monthly.index.min(), commodities_wide.index.min())
common_end   = min(fred_monthly.index.max(), commodities_wide.index.max())

fred_aligned = fred_monthly.loc[common_start:common_end].copy()
comm_aligned = commodities_wide.loc[common_start:common_end].copy()

print(f"Aligned date range: {common_start.date()} → {common_end.date()}")
print(f"FRED rows: {len(fred_aligned)}  |  Commodity rows: {len(comm_aligned)}")

# ─────────────────────────────────────────────────────────────────────────────
# Chart 1: PPI vs Commodity Prices (dual-axis)
# ─────────────────────────────────────────────────────────────────────────────
fig, ax1 = plt.subplots(figsize=(14, 6))
ax1.set_title("PPI (All Commodities) vs Critical Mineral Prices", fontsize=14, fontweight="bold")
ax1.set_xlabel("Date")
ax1.set_ylabel("PPI Index", color=ZERVE_COLORS["primary"])
ax1.plot(fred_aligned.index, fred_aligned["PPI"], color=ZERVE_COLORS["primary"],
         linewidth=2, label="PPI")
ax1.tick_params(axis="y", labelcolor=ZERVE_COLORS["primary"])

ax2 = ax1.twinx()
ax2.set_ylabel("Commodity Price (USD)", color=ZERVE_COLORS["accent"])
for i, mineral in enumerate(comm_aligned.columns):
    color = [ZERVE_COLORS["accent"], ZERVE_COLORS["secondary"], ZERVE_COLORS["success"]][i % 3]
    ax2.plot(comm_aligned.index, comm_aligned[mineral], color=color,
             linewidth=1.5, linestyle="--", label=mineral)
ax2.tick_params(axis="y", labelcolor=ZERVE_COLORS["accent"])

lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left", framealpha=0.9)
fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Chart 2: Industrial Production vs Commodity Prices (dual-axis)
# ─────────────────────────────────────────────────────────────────────────────
fig, ax1 = plt.subplots(figsize=(14, 6))
ax1.set_title("Industrial Production Index vs Critical Mineral Prices",
              fontsize=14, fontweight="bold")
ax1.set_xlabel("Date")
ax1.set_ylabel("Industrial Production Index", color=ZERVE_COLORS["primary"])
ax1.plot(fred_aligned.index, fred_aligned["Industrial_Production"],
         color=ZERVE_COLORS["primary"], linewidth=2, label="Industrial Production")
ax1.tick_params(axis="y", labelcolor=ZERVE_COLORS["primary"])

ax2 = ax1.twinx()
ax2.set_ylabel("Commodity Price (USD)", color=ZERVE_COLORS["accent"])
for i, mineral in enumerate(comm_aligned.columns):
    color = [ZERVE_COLORS["accent"], ZERVE_COLORS["secondary"], ZERVE_COLORS["success"]][i % 3]
    ax2.plot(comm_aligned.index, comm_aligned[mineral], color=color,
             linewidth=1.5, linestyle="--", label=mineral)
ax2.tick_params(axis="y", labelcolor=ZERVE_COLORS["accent"])

lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left", framealpha=0.9)
fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Chart 3: Rolling 12-month Correlations
# ─────────────────────────────────────────────────────────────────────────────
WINDOW = 12  # months

fig, axes = plt.subplots(1, 2, figsize=(16, 5))

for idx, macro_col in enumerate(["PPI", "Industrial_Production"]):
    ax = axes[idx]
    ax.set_title(f"Rolling {WINDOW}-Month Correlation: {macro_col} vs Commodities",
                 fontsize=12, fontweight="bold")
    ax.set_xlabel("Date")
    ax.set_ylabel("Pearson r")
    ax.axhline(0, color="grey", linewidth=0.8, linestyle="--")

    for i, mineral in enumerate(comm_aligned.columns):
        combined = pd.DataFrame({
            "macro": fred_aligned[macro_col],
            "mineral": comm_aligned[mineral],
        }).dropna()

        if len(combined) < WINDOW:
            continue

        rolling_corr = combined["macro"].rolling(WINDOW).corr(combined["mineral"])
        color = [ZERVE_COLORS["accent"], ZERVE_COLORS["secondary"], ZERVE_COLORS["success"]][i % 3]
        ax.plot(combined.index, rolling_corr, label=mineral, color=color, linewidth=1.5)

    ax.legend(loc="lower left", framealpha=0.9)
    ax.set_ylim(-1, 1)

fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Chart 4 / Table: Lead-Lag Cross-Correlation Analysis
# ─────────────────────────────────────────────────────────────────────────────
MAX_LAG = 6  # months

def _xcorr(macro_series: pd.Series, commodity_series: pd.Series,
           max_lag: int) -> pd.DataFrame:
    """Compute cross-correlation at lags -max_lag..+max_lag (months)."""
    results = []
    combined = pd.DataFrame({"macro": macro_series, "commodity": commodity_series}).dropna()
    n = len(combined)
    for lag in range(-max_lag, max_lag + 1):
        if lag < 0:
            x = combined["macro"].iloc[:lag].values
            y = combined["commodity"].iloc[-lag:].values
        elif lag > 0:
            x = combined["macro"].iloc[lag:].values
            y = combined["commodity"].iloc[:-lag].values
        else:
            x = combined["macro"].values
            y = combined["commodity"].values

        if len(x) < 5:
            continue
        r, p = stats.pearsonr(x, y)
        results.append({"lag_months": lag, "pearson_r": round(r, 4), "p_value": round(p, 4)})
    return pd.DataFrame(results)

print("\n" + "=" * 70)
print("LEAD-LAG CROSS-CORRELATION ANALYSIS")
print("=" * 70)

lead_lag_records = []
for macro_col in ["PPI", "Industrial_Production"]:
    for mineral in comm_aligned.columns:
        xcorr_df = _xcorr(fred_aligned[macro_col], comm_aligned[mineral], MAX_LAG)
        best = xcorr_df.loc[xcorr_df["pearson_r"].abs().idxmax()]
        lead_lag_records.append({
            "Macro Indicator": macro_col,
            "Commodity": mineral,
            "Best Lag (months)": int(best["lag_months"]),
            "Pearson r": best["pearson_r"],
            "p-value": best["p_value"],
            "Direction": "Macro leads" if best["lag_months"] > 0 else (
                "Commodity leads" if best["lag_months"] < 0 else "Synchronous"
            ),
        })

lead_lag_df = pd.DataFrame(lead_lag_records)
print(lead_lag_df.to_string(index=False))
print("=" * 70)
