"""
Block 4: Commodity Price Forecasting
======================================
Trains a GradientBoostingRegressor per commodity using lagged price
features plus FRED macro indicators, generates a 12-month forward
forecast with bootstrap confidence intervals.

Zerve DAG position: Depends on fred_df (Block 1) and commodities_df (Block 2).
Output variables: forecast_df, model performance metrics
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ─────────────────────────────────────────────────────────────────────────────
# Design colours (Zerve palette)
# ─────────────────────────────────────────────────────────────────────────────
ZERVE_COLORS = {
    "primary":   "#2E86AB",
    "secondary": "#A23B72",
    "accent":    "#F18F01",
    "success":   "#2BA84A",
    "dark":      "#1B1B2F",
}

# ─────────────────────────────────────────────────────────────────────────────
# Feature engineering: lag features + FRED macro merge
# ─────────────────────────────────────────────────────────────────────────────
LAG_MONTHS = [1, 2, 3, 6, 12]
FORECAST_HORIZON = 12  # months ahead
N_BOOTSTRAP = 200

def build_features(commodity_label: str,
                   commodities_df: pd.DataFrame,
                   fred_df: pd.DataFrame) -> pd.DataFrame:
    """Build feature matrix for a single commodity."""
    cdf = (
        commodities_df[commodities_df["commodity"] == commodity_label]
        .set_index("date")[["price"]]
        .resample("MS").mean()
        .sort_index()
    )

    # Lag features
    for lag in LAG_MONTHS:
        cdf[f"price_lag_{lag}"] = cdf["price"].shift(lag)

    # Rolling statistics
    cdf["price_roll_mean_3"]  = cdf["price"].rolling(3).mean()
    cdf["price_roll_std_3"]   = cdf["price"].rolling(3).std()
    cdf["price_roll_mean_12"] = cdf["price"].rolling(12).mean()

    # Month-over-month return
    cdf["price_mom"] = cdf["price"].pct_change()

    # Merge FRED macro data (monthly)
    fred_monthly = fred_df.resample("MS").mean()
    cdf = cdf.join(fred_monthly, how="left")

    # Forward-fill FRED (published with ~1-month lag)
    cdf[fred_monthly.columns] = cdf[fred_monthly.columns].ffill()

    cdf.dropna(inplace=True)
    return cdf


def train_and_forecast(commodity_label: str,
                       commodities_df: pd.DataFrame,
                       fred_df: pd.DataFrame) -> dict:
    """Train model, evaluate, and produce 12-month forecast with CI."""
    feat = build_features(commodity_label, commodities_df, fred_df)

    target = "price"
    feature_cols = [c for c in feat.columns if c != target]
    X = feat[feature_cols].values
    y = feat[target].values
    dates = feat.index

    # Time-series cross-validation
    tscv = TimeSeriesSplit(n_splits=5)
    cv_scores = {"mae": [], "rmse": [], "r2": []}

    for train_idx, test_idx in tscv.split(X):
        X_tr, X_te = X[train_idx], X[test_idx]
        y_tr, y_te = y[train_idx], y[test_idx]
        mdl = GradientBoostingRegressor(
            n_estimators=200, max_depth=4, learning_rate=0.05,
            subsample=0.8, random_state=42
        )
        mdl.fit(X_tr, y_tr)
        preds = mdl.predict(X_te)
        cv_scores["mae"].append(mean_absolute_error(y_te, preds))
        cv_scores["rmse"].append(np.sqrt(mean_squared_error(y_te, preds)))
        cv_scores["r2"].append(r2_score(y_te, preds))

    # Final model on all data
    model = GradientBoostingRegressor(
        n_estimators=200, max_depth=4, learning_rate=0.05,
        subsample=0.8, random_state=42
    )
    model.fit(X, y)

    # ── 12-month recursive forecast ──────────────────────────────────────
    last_row = feat.iloc[[-1]].copy()
    forecast_dates = pd.date_range(
        start=dates[-1] + pd.DateOffset(months=1), periods=FORECAST_HORIZON, freq="MS"
    )
    forecasts = []
    current = last_row.copy()

    for fdate in forecast_dates:
        pred = model.predict(current[feature_cols].values)[0]
        forecasts.append(pred)

        # Shift lags forward
        new_row = current.copy()
        for lag in sorted(LAG_MONTHS):
            col = f"price_lag_{lag}"
            if lag == 1:
                new_row[col] = pred
            else:
                prev_col = f"price_lag_{lag - 1}" if (lag - 1) in LAG_MONTHS else None
                if prev_col and prev_col in new_row.columns:
                    new_row[col] = current[prev_col].values[0]
        new_row["price"] = pred
        new_row["price_mom"] = (pred - current["price"].values[0]) / current["price"].values[0]
        new_row["price_roll_mean_3"] = pred   # simplified
        new_row["price_roll_std_3"]  = 0.0
        new_row["price_roll_mean_12"] = pred
        current = new_row

    # ── Bootstrap confidence intervals ───────────────────────────────────
    residuals = y - model.predict(X)
    boot_forecasts = np.zeros((N_BOOTSTRAP, FORECAST_HORIZON))
    rng = np.random.RandomState(42)
    for b in range(N_BOOTSTRAP):
        noise = rng.choice(residuals, size=FORECAST_HORIZON, replace=True)
        boot_forecasts[b, :] = np.array(forecasts) + noise

    ci_lower = np.percentile(boot_forecasts, 5, axis=0)
    ci_upper = np.percentile(boot_forecasts, 95, axis=0)

    forecast_df = pd.DataFrame({
        "date": forecast_dates,
        "commodity": commodity_label,
        "forecast_price": np.round(forecasts, 2),
        "ci_lower_90": np.round(ci_lower, 2),
        "ci_upper_90": np.round(ci_upper, 2),
    })

    return {
        "commodity": commodity_label,
        "model": model,
        "feature_cols": feature_cols,
        "cv_mae":  np.mean(cv_scores["mae"]),
        "cv_rmse": np.mean(cv_scores["rmse"]),
        "cv_r2":   np.mean(cv_scores["r2"]),
        "forecast_df": forecast_df,
        "history_dates": dates,
        "history_prices": y,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Run forecasting pipeline for each commodity
# ─────────────────────────────────────────────────────────────────────────────
MINERALS = commodities_df["commodity"].unique().tolist()
results = {}
all_forecasts = []

print("=" * 70)
print("COMMODITY PRICE FORECASTING — GradientBoosting + Bootstrap CI")
print("=" * 70)

for mineral in MINERALS:
    print(f"\n▶ {mineral}")
    res = train_and_forecast(mineral, commodities_df, fred_df)
    results[mineral] = res
    all_forecasts.append(res["forecast_df"])
    print(f"  CV MAE  : {res['cv_mae']:.4f}")
    print(f"  CV RMSE : {res['cv_rmse']:.4f}")
    print(f"  CV R²   : {res['cv_r2']:.4f}")

forecast_df = pd.concat(all_forecasts, ignore_index=True)

# ─────────────────────────────────────────────────────────────────────────────
# Performance summary table
# ─────────────────────────────────────────────────────────────────────────────
perf_df = pd.DataFrame([{
    "Commodity": r["commodity"],
    "CV MAE": round(r["cv_mae"], 4),
    "CV RMSE": round(r["cv_rmse"], 4),
    "CV R²": round(r["cv_r2"], 4),
} for r in results.values()])

print("\n" + "─" * 50)
print("MODEL PERFORMANCE SUMMARY")
print("─" * 50)
print(perf_df.to_string(index=False))

# ─────────────────────────────────────────────────────────────────────────────
# Forecast chart per commodity
# ─────────────────────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, len(MINERALS), figsize=(6 * len(MINERALS), 5), sharey=False)
if len(MINERALS) == 1:
    axes = [axes]

colors = [ZERVE_COLORS["primary"], ZERVE_COLORS["secondary"], ZERVE_COLORS["accent"]]

for idx, mineral in enumerate(MINERALS):
    ax = axes[idx]
    r = results[mineral]
    fc = r["forecast_df"]

    ax.plot(r["history_dates"], r["history_prices"],
            color=colors[idx % 3], linewidth=1.5, label="Historical")
    ax.plot(fc["date"], fc["forecast_price"],
            color=colors[idx % 3], linewidth=2, linestyle="--", label="Forecast")
    ax.fill_between(fc["date"], fc["ci_lower_90"], fc["ci_upper_90"],
                    color=colors[idx % 3], alpha=0.15, label="90 % CI")
    ax.set_title(f"{mineral} — 12-Month Forecast", fontsize=12, fontweight="bold")
    ax.set_xlabel("Date")
    ax.set_ylabel("Price (USD)")
    ax.legend(fontsize=9)

fig.suptitle("CritMin Compass — Commodity Price Forecasts",
             fontsize=14, fontweight="bold", y=1.02)
fig.tight_layout()
plt.show()

# ─────────────────────────────────────────────────────────────────────────────
# Print 12-month forecast table
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("12-MONTH FORECAST TABLE")
print("=" * 70)
print(forecast_df.to_string(index=False))
