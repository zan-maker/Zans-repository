# CritMin Compass — Pipeline Architecture

## Overview

CritMin Compass is a 9-block Zerve DAG pipeline that ingests macroeconomic,
commodity price, and regulatory filing data to produce supply chain
intelligence for critical minerals (Lithium, Nickel, Cobalt).

---

## Data Sources

### 1. FRED Macroeconomic Indicators

| Field                | Detail                                       |
|----------------------|----------------------------------------------|
| **API**              | Federal Reserve Bank of St. Louis (FRED)     |
| **Endpoint**         | `https://api.stlouisfed.org/fred/series/observations` |
| **Series**           | PPI (PPIACO), Industrial Production (INDPRO), Trade Balance (BOPGSTB) |
| **Granularity**      | Monthly                                      |
| **Date range**       | 2020-01-01 onward                            |
| **Refresh cadence**  | Monthly (PPI & INDPRO ~15th; Trade Balance ~5th of following month) |
| **Schema**           | DatetimeIndex, columns: `PPI`, `Industrial_Production`, `Trade_Balance` |
| **Output variable**  | `fred_df`                                    |

### 2. Commodity Spot Prices (Alpha Vantage)

| Field                | Detail                                       |
|----------------------|----------------------------------------------|
| **API**              | Alpha Vantage Physical Commodities           |
| **Endpoint**         | `https://www.alphavantage.co/query`          |
| **Commodities**      | LITHIUM (proxy: ALUMINUM), NICKEL (proxy: COPPER), COBALT (proxy: ALL_COMMODITIES) |
| **Granularity**      | Monthly                                      |
| **Date range**       | Full history available (1990s onward)        |
| **Refresh cadence**  | Monthly, ~1-week lag                         |
| **Schema**           | Columns: `date`, `price`, `commodity`        |
| **Output variable**  | `commodities_df`                             |

### 3. SEC EDGAR Supply Chain Filings

| Field                | Detail                                       |
|----------------------|----------------------------------------------|
| **API**              | SEC EDGAR Full-Text Search                   |
| **Fallback**         | API Ninjas Commodity Price endpoint           |
| **Form types**       | 10-K, 10-Q                                   |
| **Search terms**     | lithium supply chain, cobalt sourcing, nickel mining, critical mineral, battery supply chain, rare earth supply |
| **Date range**       | 2020-01-01 to 2026-01-01                    |
| **Refresh cadence**  | Real-time (SEC filings published continuously)|
| **Schema**           | Columns: `company`, `cik`, `form_type`, `date`, `title`, `url`, `source`, `query` |
| **Output variable**  | `edgar_df`                                   |

---

## DAG Block Dependencies

```
Block 1 (FRED)  ──────────┐
                           ├──→ Block 3 (PPI/INDPRO Analysis)
Block 2 (Commodities) ────┤
                           ├──→ Block 4 (Price Forecasting)
                           │
Block 5 (SEC EDGAR) ──────┼──→ Block 6 (Summary Report) ← Blocks 1,2,5
                           │
                           ├──→ Block 7 (NLP Sentiment) ──→ Block 8 (Correlations) ← Blocks 1,2,7
                           │
                           └──→ Block 9 (Linguistic Analysis)
```

---

## Environment Variables

| Variable               | Required | Source                     |
|------------------------|----------|----------------------------|
| `FRED_API_KEY`         | Yes      | https://fred.stlouisfed.org/docs/api/api_key.html |
| `ALPHA_VANTAGE_API_KEY`| Yes      | https://www.alphavantage.co/support/#api-key |
| `API_NINJAS_KEY`       | Yes      | https://api-ninjas.com/     |
