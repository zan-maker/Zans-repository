# ZerveHack Project Proposal: CritMin Compass

---

## Elevator Pitch (< 200 characters)

**AI-powered critical minerals supply chain risk scorer — combines FRED macro data, SEC filings, and trade policy signals to forecast battery material pricing disruptions in real time.**

---

## Project Name: **CritMin Compass** — Critical Minerals Intelligence Engine

---

## Inspiration

The global battery supply chain is a $200B+ market undergoing tectonic regulatory shifts: the IRA Section 45X production credits, the October 2027 FEOC Chinese battery procurement ban, EU CRMA due diligence requirements, and escalating tariff regimes. Yet most commodity intelligence tools are backward-looking dashboards built for traders — not for the operators, CFOs, and policy teams who need to understand *what's coming next* and *what it means for their business*.

I run a battery recycling company. Every week I'm asked: "What happens to our unit economics if lithium carbonate drops another 15%?" or "How does the new FEOC rule change our competitive position vs. Chinese pCAM?" These questions require synthesizing macro data (FRED), commodity prices (Alpha Vantage), regulatory event timelines, and company filings (SEC EDGAR) — work that takes analysts hours and is stale by the time it's done.

I wanted to build the tool I wish existed: a live intelligence engine that connects the dots between macro signals, commodity pricing, and regulatory catalysts — and tells you what's likely to happen next, with confidence intervals.

---

## What It Does

**CritMin Compass** is a critical minerals supply chain risk and opportunity scoring platform built entirely in Zerve. It:

1. **Ingests live data** from FRED (macro indicators: PPI, industrial production, trade balances), Alpha Vantage (lithium, nickel, cobalt spot prices), and SEC EDGAR (battery/EV company 10-K/10-Q filings for supply chain language).

2. **Runs a multi-signal risk model** that scores supply chain disruption probability across five dimensions:
   - **Price Volatility Risk** — rolling volatility + regime detection on battery material prices
   - **Macro Stress** — leading indicators (yield curve, PMI, industrial production) correlated with commodity demand
   - **Regulatory Impact** — NLP-scored proximity to key policy dates (FEOC ban, IRA credit phase-downs, EU CRMA deadlines) using Gemini API for semantic classification of regulatory filings
   - **Concentration Risk** — HHI-based geographic supply concentration scoring (China/Indonesia/DRC dependency ratios)
   - **Demand Signal** — EV production forecasts vs. announced battery gigafactory capacity

3. **Generates a composite CritMin Risk Score** (0–100) updated on each run, with historical trend tracking and confidence intervals using Bayesian updating.

4. **Deploys as both an API and an interactive App:**
   - **API endpoint** returns the current risk score, component breakdowns, and top 3 risk drivers for any queried mineral (lithium, nickel, cobalt, manganese)
   - **App dashboard** shows the risk score over time, scenario toggles (e.g., "What if lithium drops 20%?"), and a regulatory countdown timeline

---

## How We Built It

**Platform:** Zerve AI — leveraging the agent for code generation, multi-language support (Python + SQL), and direct-to-production deployment.

**Data Pipeline (Python blocks in Zerve DAG):**
- `FRED API` → macro indicators (10-year series: PPI metals, industrial production, PMI, yield curve spread)
- `Alpha Vantage API` → daily commodity prices for lithium carbonate, nickel sulfate, cobalt hydroxide
- `SEC EDGAR API` → 10-K filings text extraction for top 20 battery/EV companies (Tesla, CATL ADR, Albemarle, Livent/Arcadium, etc.)
- `Static reference tables` → FEOC regulatory timeline, IRA credit schedule, country-level mineral production shares (USGS data)

**Modeling (Python blocks):**
- **Price regime detection:** Hidden Markov Model (HMM) with 3 states (low-vol, trending, crisis) on rolling 60-day commodity windows
- **Macro correlation engine:** Granger causality tests linking leading indicators to 30/60/90-day commodity price moves
- **Regulatory NLP:** Google Gemini API (gemini-2.0-flash) classifies SEC filing paragraphs by regulatory relevance (FEOC, IRA, CRMA) and sentiment (risk/opportunity/neutral)
- **Composite scoring:** Weighted ensemble with Bayesian posterior updating — priors from historical disruption frequency, posteriors updated with each new data pull
- **Scenario engine:** Monte Carlo simulation (10,000 paths) for user-defined price/policy shocks

**Deployment:**
- Zerve App with input blocks for mineral selection + scenario parameters, output blocks for visualizations (Plotly charts + risk gauge)
- Zerve API endpoint returning JSON risk payload

**Workflow:**
```
[FRED Pull] → [Price Pull] → [EDGAR Pull] → [Feature Engineering] →
[HMM Regime] → [Macro Correlation] → [Gemini NLP] →
[Composite Scorer] → [Monte Carlo Scenarios] → [Dashboard / API]
```

---

## Challenges We Ran Into

- **Data alignment:** FRED publishes monthly, prices are daily, SEC filings are quarterly. Normalizing these to a common decision frequency required careful interpolation logic — Zerve's agent helped iterate through alignment approaches quickly.
- **Gemini API rate limits:** Batching 10-K paragraph classification required chunking strategy and retry logic. We used Zerve's parallel block execution to process multiple filings simultaneously.
- **Avoiding overfitting the composite score:** With only ~15 historical supply disruption events to calibrate against (2018 cobalt crisis, 2022 lithium spike, 2024 nickel collapse), we used informative Bayesian priors rather than purely data-driven weights.
- **Making it actionable, not just analytical:** The hardest design challenge was translating statistical outputs into decision-useful risk language — confidence intervals and scenario ranges rather than false-precision point estimates.

---

## Accomplishments We're Proud Of

- **End-to-end in Zerve:** From raw API calls to deployed app and API — zero infrastructure management, zero context switching. The agent handled dependency management and deployment configuration.
- **Gemini-powered regulatory intelligence:** Using LLM classification to score SEC filings for regulatory exposure is genuinely novel in this space — most commodity tools ignore the regulatory dimension entirely.
- **Bayesian scoring with honest uncertainty:** Rather than a black-box risk number, every score comes with a credible interval and the top contributing factors — making it auditable and decision-useful.
- **Real business utility:** This isn't a toy demo. The scenario engine directly answers questions we face weekly in pre-IPO investor meetings: "What's your downside if lithium hits $8/kg?" or "How does the FEOC ban change your competitive moat?"

---

## What We Learned

- **Zerve's agent dramatically compresses iteration cycles.** What would normally be hours of debugging data pipeline mismatches became minutes of agent-assisted troubleshooting with full data context.
- **Domain expertise is the real moat in data science.** The model architecture is straightforward — the value is in knowing *which* signals matter, *which* regulatory dates are catalytic, and *how* supply chain actors actually respond to price shocks. AI handles execution; domain knowledge sets direction.
- **Bayesian thinking forces intellectual honesty.** When you have to specify priors explicitly, you can't hide behind "the model says so." Every assumption is visible and challengeable.
- **Deploying from notebook to API in Zerve is genuinely frictionless.** No Docker files. No YAML. No deployment pipelines. The workflow *is* the deployment artifact.

---

## What's Next for CritMin Compass

- **Live scheduling:** Set up Zerve scheduled jobs for daily data refresh and weekly risk score publication
- **Expand mineral coverage:** Add rare earths (neodymium, dysprosium) and graphite — critical for motors and anodes
- **Integrate trade flow data:** Use UN Comtrade API for real-time import/export shift detection (early warning for supply rerouting through non-FEOC jurisdictions)
- **Investor-facing variant:** Package the API output into an auto-generated investor brief — directly usable in VDR materials for the ASX listing process
- **Alert system:** Push notifications when composite risk score crosses predefined thresholds or when a new regulatory filing triggers a material classification change

---

## Technical Stack Summary

| Component | Tool |
|---|---|
| Platform | Zerve AI |
| Languages | Python, SQL |
| Data Sources | FRED API, Alpha Vantage, SEC EDGAR, USGS static data |
| AI/LLM | Google Gemini 2.0 Flash (regulatory NLP classification) |
| Modeling | scikit-learn, hmmlearn, scipy (Bayesian), numpy |
| Visualization | Plotly |
| Deployment | Zerve App + Zerve API |

---

## Category Fit

**Primary:** Finance & Economics
**Secondary:** Wildcard (Bring Your Own Domain — Critical Minerals / Battery Supply Chain)

---

*Built with Zerve. Powered by domain obsession.*
